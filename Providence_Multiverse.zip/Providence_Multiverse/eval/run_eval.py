from __future__ import annotations

import json
from pathlib import Path

# Allow running as a script: `python eval/run_eval.py`
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from config_loader import load_config
from router.heuristic_router import HeuristicRouter


def main() -> int:
    cfg = load_config("config/config.yaml")
    router = HeuristicRouter(domains=cfg.domains)

    path = Path("eval/core_tasks.jsonl")
    correct = 0
    total = 0
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        rr = router.route(row["prompt"])
        total += 1
        if rr.top_domain == row["domain"]:
            correct += 1
    acc = correct / max(1, total)
    print(f"Routing top-1 accuracy (heuristic router): {acc:.2f} ({correct}/{total})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
