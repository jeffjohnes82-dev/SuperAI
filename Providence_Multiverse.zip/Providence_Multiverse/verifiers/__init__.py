"""Verification utilities.

The 'accuracy/hallucination loop' uses these verifiers to compute a real signal
from outputs (pass/fail/unknown) and then adapts verification_strictness.
"""

__all__ = [
    "claim_extractor",
    "math_verifier",
    "unit_verifier",
]
