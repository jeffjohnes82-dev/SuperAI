from __future__ import annotations

import math
import re
from typing import Any, Dict

from schemas.claims import VerificationResult


def _is_number(s: str) -> bool:
    try:
        float(s)
        return True
    except Exception:
        return False


def verify_math_claim(claim: Dict[str, Any]) -> Dict[str, Any]:
    """Very small v1 math verifier.

    In this mockup, brains rarely output explicit formulas. We still verify that a
    numeric value is well-formed and finite. Upgrade path: add sympy-based parsing
    and re-computation when claims include expressions.
    """
    val = str(claim.get("value") or "").strip()
    if not val:
        return VerificationResult(claim_id=claim["id"], status="unknown", reason="no value").to_dict()

    if not _is_number(val):
        return VerificationResult(claim_id=claim["id"], status="fail", reason=f"not a number: {val}").to_dict()

    x = float(val)
    if math.isnan(x) or math.isinf(x):
        return VerificationResult(claim_id=claim["id"], status="fail", reason="non-finite number").to_dict()

    # basic significant-figure sanity check: reject obvious junk like '0000.000'
    if re.fullmatch(r"0+(\.0+)?", val):
        return VerificationResult(claim_id=claim["id"], status="unknown", reason="all-zeros; cannot verify").to_dict()

    return VerificationResult(claim_id=claim["id"], status="pass", reason="numeric value is finite").to_dict()
