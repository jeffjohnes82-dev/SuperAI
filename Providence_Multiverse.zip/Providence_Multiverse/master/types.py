from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, TypedDict


class BrainOutput(TypedDict, total=False):
    brain: str
    answer: str
    confidence: float  # 0..1
    overlay: str
    details: str
    metadata: Dict[str, Any]
    claims: List[Dict[str, Any]]
    verifications: List[Dict[str, Any]]
    verified: bool
    verified_score: float
    hallucination_estimate: float
    can_finalize: bool
    verification_reason: str
    final: bool


@dataclass(frozen=True)
class RouteResult:
    probs: Dict[str, float]
    top_domain: str
    top_p: float
    runner_up_domain: str
    runner_up_p: float
