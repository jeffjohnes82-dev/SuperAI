# Providence Multiverse

This is a minimal, **working** scaffold for a "Master Brain" orchestrator that routes queries to specialist "brains" using a domain router.
## Multiverse module

This version includes a **theoretical-only** multiverse capability (no real-physics access).
See `docs/MULTIVERSE.md` and the `multiverse:` section in `config/config.yaml`.


## Routing policy (configurable)
Located in `config/config.yaml`:
- **Reject** if `top_p < 0.50`
- **Exclusive** if `top_p >= 0.90` → route to **one** brain (no helpers)
- **Multi-brain** if `0.50 <= top_p < 0.90` → route to **top-k** brains and merge

## Brainchild Mega (self-evolving control layer)
Optional online learning layer in `brainchild_mega/` that continuously tunes:
- **Decision/traversal** (bandit-style selection of leaves during multi-brain)
- **Accuracy/hallucination** (tighten verification strictness + cap confidence when hallucination rises)
- **Progress** (relax reject threshold / increase top-k when success drops)
- **Scholastic tracking** (simple skill meter for math/physics/AI)
- **Resource allocation** (Lagrangian-style budget scaling under cost/latency/hallucination constraints)

State is stored in `brainchild_mega/state/mega_state.json`.

## Install

1) Create and activate a virtual environment (recommended)
2) Install requirements:

```bash
pip install -r requirements.txt
```

## Run

```bash
python main.py "Explain quantum entanglement simply"
python eval/run_eval.py
```

You should see:
- router probabilities
- selected brains
- final response (overlay + details)

## Project layout

- `main.py` — CLI entrypoint
- `config/` — YAML config
- `master/` — orchestrator + policy + merge
- `router/` — domain router (heuristic v1)
- `brains/` — specialist brains (template stubs; replace with model calls)
- `eval/` — evaluation dataset + scripts (stub)
- `logs/` — JSON run logs
- `brainchild_mega/` — self-evolving decision/accuracy/progress/scholastic/optimization modules

## Domains
Configured in `config/config.yaml`:
- `physics`, `chemistry`, `biology` (science subdomains)
- `science` (cross-disciplinary science fallback)
- `math`, `statistics`, `logic`, `coding`
- `ai`, `software_engineering`, `electrical`, `mechanical`, `civil`, `aerospace`
- `planning`, `research`, `writing`, `general`

## Taxonomy
The repo also ships a simple 3-branch taxonomy (editable in YAML):
- **NatSci**: physics/chemistry/biology/science
- **ForSci**: math/statistics/logic/coding
- **TechEng**: ai/software_engineering/electrical/mechanical/civil/aerospace

## Next steps
- Replace `router/heuristic_router.py` with an LLM or ML classifier
- Replace `brains/*` implementations with real model/tool calls
- Add verification gates (math/code/facts) and scoring

### Science subdomains
The mockup includes separate brains/domains for:
- `physics`
- `chemistry`
- `biology`
- `science` (umbrella / cross-disciplinary fallback)
