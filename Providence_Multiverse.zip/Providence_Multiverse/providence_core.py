from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from config_loader import load_config
from brains.registry import build_brain_registry
from master.orchestrator import MasterBrain
from master.verification_gate import verify_output
from router.taxonomy_router import TaxonomyRouter
from router.technicality import score_technicality
from brainchild_mega import estimate_hallucination, estimate_verified
from brainchild_mega.decision.tree_struct import build_tree_from_taxonomy


def run_query(
    query: str,
    config_path: str = "config/config.yaml",
    session_id: Optional[str] = None,
    history: Optional[List[Dict[str, str]]] = None,
    log_dir: str | Path = "logs",
) -> Dict[str, Any]:
    """Run a single Providence query and return a structured payload for the UI."""

    cfg = load_config(config_path)

    # Technical focus gate (technical / technical+social / technical+creative)
    tech_res = score_technicality(query)
    allowed = set((cfg.focus.get("allowed") or []))
    hard_reject_below = float((cfg.focus.get("technicality") or {}).get("hard_reject_below", 0.0))
    clarify_band = (cfg.focus.get("technicality") or {}).get("clarify_band", {})

    # Build tree for debug
    nodes, edges = build_tree_from_taxonomy(cfg.taxonomy)

    # Domains are taxonomy leaves + 'general'. Exclude reserved leaves from routing.
    reserved_leaf_suffixes = {"final_reasoner"}
    leaf_ids = [
        d
        for d in cfg.domains
        if d != "general" and d.split(".")[-1] not in reserved_leaf_suffixes
    ]

    router = TaxonomyRouter(leaf_ids=leaf_ids, taxonomy=cfg.taxonomy)
    rr = router.route(query)

    brains = build_brain_registry(cfg.domains)
    master = MasterBrain(cfg.raw, log_dir=Path(log_dir))

    # Focus gate can override decision
    focus_override_mode = None
    if tech_res.label not in allowed:
        # Clarify band behavior: ask user to reframe technically
        if clarify_band.get("enabled") and clarify_band.get("low", 0) <= tech_res.score <= clarify_band.get("high", 0):
            focus_override_mode = "clarify"
        elif tech_res.score < hard_reject_below:
            focus_override_mode = "reject"
        else:
            focus_override_mode = "clarify"

    decision = master.decide(rr)
    if focus_override_mode in {"clarify", "reject"}:
        decision.mode = focus_override_mode
        decision.chosen_brains = []
        decision.meta = {"focus_gate": {"label": tech_res.label, "score": tech_res.score}}

    # Budgets (scaled by Mega)
    total_budget_base = int(cfg.raw.get("budgets", {}).get("token_budget_total", 2400))
    budget_scale = float(master.mega.state.get("optimization", {}).get("budget_scale", 1.0)) if master.mega.enabled else 1.0
    total_budget = max(1, int(round(total_budget_base * budget_scale)))

    seq_stop = bool(cfg.raw.get("brainchild_mega", {}).get("decision", {}).get("sequential_stop", True))
    stop_conf = float(cfg.raw.get("brainchild_mega", {}).get("decision", {}).get("stop_if_confidence_at_least", 0.90))

    strict_default = float(cfg.raw.get("verification", {}).get("strictness_default", 0.50))
    strictness = (
        float(master.mega.state.get("accuracy", {}).get("verification_strictness", strict_default))
        if master.mega.enabled
        else strict_default
    )

    executed: List[str] = []
    outputs: List[Dict[str, Any]] = []

    per_brain = max(1, total_budget // max(1, len(decision.chosen_brains) or 1))

    import time as _time
    t0 = _time.time()

    for dom in decision.chosen_brains:
        brain = brains.get(dom, brains["general"])
        ctx = {
            "session_id": session_id,
            "history": history or [],
            "technicality": tech_res.__dict__,
        }
        out = brain.solve(query, context=ctx, budget=per_brain)

        vs = verify_output(query=query, domain=dom, output=out, strictness=strictness)
        out["claims"] = vs.claims
        out["verifications"] = vs.verifications
        out["verified_score"] = vs.verified_score
        out["hallucination_estimate"] = vs.hallucination_estimate
        out["can_finalize"] = vs.can_finalize
        out["verification_reason"] = vs.reason
        out["verified"] = bool(vs.can_finalize and (vs.verified_score or 0.0) >= 0.80)

        outputs.append(out)
        executed.append(dom)

        leaf_ready = (out.get("final") is True) or (float(out.get("confidence", 0.0)) >= stop_conf)
        if seq_stop and leaf_ready and bool(out.get("can_finalize", True)):
            break

    latency_seconds = _time.time() - t0

    final = master.merge(decision, outputs, rr)

    # Premium: AI branch can take a final reasoning pass (synthesis leaf).
    ai_final_cfg = cfg.raw.get("ai_final_reasoner", {}) or {}
    ai_final_used = False
    ai_leaf = str(ai_final_cfg.get("leaf", "ai.final_reasoner"))
    if bool(ai_final_cfg.get("enabled", False)) and decision.mode in {"exclusive", "multi"}:
        ai_brain = brains.get(ai_leaf)
        if ai_brain is not None:
            budget_fraction = float(ai_final_cfg.get("budget_fraction", 0.25) or 0.25)
            ai_budget = max(1, int(round(total_budget * max(0.05, min(0.6, budget_fraction)))))
            ai_ctx = {
                "candidate_outputs": outputs,
                "candidate_final": final,
                "verification_strictness": strictness,
                "session_id": session_id,
            }
            ai_out = ai_brain.solve(query, context=ai_ctx, budget=ai_budget)
            vs_ai = verify_output(query=query, domain=ai_leaf, output=ai_out, strictness=strictness)
            ai_out["claims"] = vs_ai.claims
            ai_out["verifications"] = vs_ai.verifications
            ai_out["verified_score"] = vs_ai.verified_score
            ai_out["hallucination_estimate"] = vs_ai.hallucination_estimate
            ai_out["can_finalize"] = vs_ai.can_finalize
            ai_out["verification_reason"] = vs_ai.reason
            ai_out["verified"] = bool(vs_ai.can_finalize and (vs_ai.verified_score or 0.0) >= 0.80)

            # Treat AI reasoner as the final leaf output.
            final = ai_out
            ai_final_used = True

    # Strict-mode blocking
    strict_high = float(cfg.raw.get("verification", {}).get("bands", {}).get("high", 0.70))
    if strictness >= strict_high:
        verifs = list(final.get("verifications") or [])
        fails = [v for v in verifs if v.get("status") == "fail"]
        if fails:
            final["final"] = False
            final["confidence"] = min(float(final.get("confidence", rr.top_p)), 0.55)
            final["overlay"] = "Verification failed under strict mode — I need more grounding to answer."

    hallu_est = estimate_hallucination(final)
    verified_est = estimate_verified(final)

    if executed:
        master.mega.update_from_run(
            leaf_id=executed[0],
            final_output=final,
            was_reject=(decision.mode == "reject"),
            cost_tokens=float(total_budget),
            latency_seconds=float(latency_seconds),
            hallucination_estimate=float(hallu_est),
            verified_estimate=float(verified_est),
        )

    payload: Dict[str, Any] = {
        "query": query,
        "technicality": tech_res.__dict__,
        "tree": {
            "nodes": {k: vars(v) for k, v in nodes.items()},
            "edges": [vars(e) for e in edges],
        },
        "router": {
            "top_leaf": rr.top_domain,
            "top_p": rr.top_p,
            "runner_up_leaf": rr.runner_up_domain,
            "runner_up_p": rr.runner_up_p,
            "probs": rr.probs,
        },
        "decision": {
            "mode": decision.mode,
            "chosen": decision.chosen_brains,
            "executed": executed,
            "per_brain_budget": per_brain,
            "meta": decision.meta,
        },
        "runtime": {
            "budget_scale": budget_scale,
            "total_budget": total_budget,
            "latency_seconds": latency_seconds,
            "verification_strictness": strictness,
        },
        "mega_state": master.mega.state if master.mega.enabled else None,
        "outputs": outputs,
        "final": final,
        "ai_final_reasoner": {"enabled": bool(ai_final_cfg.get("enabled", False)), "used": ai_final_used, "leaf": ai_leaf},
    }

    master.log_run(payload)
    return payload
