# Tooling stubs live here (calculator, code runner, retrieval, etc.)
