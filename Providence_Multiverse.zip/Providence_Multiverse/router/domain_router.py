from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple


@dataclass
class RouteResult:
    probs: Dict[str, float]
    top_domain: str
    top_p: float
    runner_up_domain: str
    runner_up_p: float


class DomainRouter:
    """Heuristic router (v1).

    Replace this later with:
    - an LLM JSON classifier, or
    - a small supervised classifier.

    The only contract that matters: return calibrated-ish probabilities.
    """

    def __init__(self, domains: List[str]):
        self.domains = domains

    def route(self, query: str) -> RouteResult:
        q = (query or "").lower()
        probs = {d: 0.0 for d in self.domains}

        # Simple keyword heuristics
        physics_kw = ["physics", "quantum", "relativity", "entanglement", "gravity", "electromagnet", "thermodynamics", "optics", "mechanics"]
        chemistry_kw = ["chemistry", "molecule", "reaction", "stoichiometry", "molar", "acid", "base", "pka", "oxidation", "bond", "periodic", "organic"]
        biology_kw = ["biology", "cell", "enzyme", "dna", "rna", "protein", "genetics", "evolution", "neuron", "immune", "microbiology"]
        science_kw = ["science", "experiment", "hypothesis", "model", "theory", "data"]
        math_kw = ["integral", "derivative", "proof", "theorem", "matrix", "vector", "probability", "calculus", "algebra"]
        coding_kw = ["python", "typescript", "javascript", "java", "c++", "bug", "compile", "api", "stack trace", "exception"]
        planning_kw = ["plan", "roadmap", "schedule", "milestone", "prioritize", "strategy"]
        writing_kw = ["rewrite", "tone", "grammar", "essay", "poem", "story"]
        research_kw = ["sources", "citations", "paper", "study", "compare", "evidence", "literature"]

        def has_any(keywords):
            return any(k in q for k in keywords)

        # Score domains
        if "physics" in probs and has_any(physics_kw):
            probs["physics"] += 3.0
        if "chemistry" in probs and has_any(chemistry_kw):
            probs["chemistry"] += 3.0
        if "biology" in probs and has_any(biology_kw):
            probs["biology"] += 3.0
        if "science" in probs and has_any(science_kw):
            probs["science"] += 2.0
        if "math" in probs and has_any(math_kw):
            probs["math"] += 3.0
        if "coding" in probs and has_any(coding_kw):
            probs["coding"] += 3.0
        if "planning" in probs and has_any(planning_kw):
            probs["planning"] += 2.0
        if "writing" in probs and has_any(writing_kw):
            probs["writing"] += 2.0
        if "research" in probs and has_any(research_kw):
            probs["research"] += 2.0

        # Generic fallback signal
        if "general" in probs:
            probs["general"] += 1.0

        # If nothing triggered, make it uncertain (so it can fall under reject/clarify policy)
        if max(probs.values()) <= 1.0 and "general" in probs:
            # deliberately keep top around ~0.49 by shaping weights
            probs = {d: (0.49 if d == "general" else 0.51/(len(self.domains)-1)) for d in self.domains}

        # Normalize
        s = sum(probs.values())
        probs = {k: (v / s if s > 0 else 1.0 / len(self.domains)) for k, v in probs.items()}

        # Top-2
        sorted_items = sorted(probs.items(), key=lambda kv: kv[1], reverse=True)
        (top_domain, top_p) = sorted_items[0]
        (runner_up_domain, runner_up_p) = sorted_items[1] if len(sorted_items) > 1 else (top_domain, 0.0)

        return RouteResult(
            probs=probs,
            top_domain=top_domain,
            top_p=float(top_p),
            runner_up_domain=runner_up_domain,
            runner_up_p=float(runner_up_p),
        )
