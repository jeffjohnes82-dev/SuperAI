from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class TechnicalityResult:
    score: float  # 0..1
    label: str    # technical | technical_social | technical_creative | nontechnical
    tech_hits: int
    social_hits: int
    creative_hits: int


TECH_WORDS: List[str] = [
    "calculate", "equation", "derive", "integral", "proof", "theorem", "model", "algorithm", "complexity",
    "optimize", "gradient", "neural", "transformer", "llm", "api", "debug", "compile", "circuit", "voltage",
    "force", "energy", "molar", "stoichiometry", "dna", "genome", "orbit", "aerodynamics", "control",
    "robot", "embedded", "pipeline", "etl", "database", "schema", "encryption", "threat model",
]

SOCIAL_WORDS: List[str] = [
    "email", "message", "reply", "interview", "manager", "team", "meeting", "negotiation", "conflict",
    "presentation", "stakeholder", "client",
]

CREATIVE_WORDS: List[str] = [
    "write a story", "poem", "lyrics", "novel", "character", "plot", "mood", "creative",
]


def _count_hits(q: str, words: List[str]) -> int:
    q = q.lower()
    return sum(1 for w in words if w in q)


def score_technicality(query: str) -> TechnicalityResult:
    q = (query or "").lower()
    tech = _count_hits(q, TECH_WORDS)
    social = _count_hits(q, SOCIAL_WORDS)
    creative = _count_hits(q, CREATIVE_WORDS)

    # Symbol/codelike boosts
    if any(ch.isdigit() for ch in q):
        tech += 1
    if any(tok in q for tok in ["=", "->", "{", "}", "::", "#include", "def ", "class "]):
        tech += 2

    # Simple normalized score
    denom = max(1, tech + social + creative)
    score = tech / denom

    if score >= 0.70:
        label = "technical"
    elif score >= 0.55:
        label = "technical_social" if social > creative else "technical_creative"
    elif score >= 0.40:
        label = "technical_social" if social >= creative else "technical_creative"
    else:
        label = "nontechnical"

    return TechnicalityResult(score=float(score), label=label, tech_hits=tech, social_hits=social, creative_hits=creative)
