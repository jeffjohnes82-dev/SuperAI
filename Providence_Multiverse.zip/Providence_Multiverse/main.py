from __future__ import annotations

import argparse
import json

from providence_core import run_query


def main() -> int:
    parser = argparse.ArgumentParser(description="Providence CLI")
    parser.add_argument("query", type=str, help="The query to route/answer")
    parser.add_argument("--config", type=str, default="config/config.yaml", help="Path to YAML config")
    parser.add_argument("--json", action="store_true", help="Print full payload as JSON")
    args = parser.parse_args()

    payload = run_query(query=args.query, config_path=args.config, session_id="cli", history=[])

    if args.json:
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return 0

    rr = payload.get("router", {})
    dec = payload.get("decision", {})
    final = payload.get("final", {})

    print("\n=== Router ===")
    print(f"top: {rr.get('top_leaf')} ({rr.get('top_p'):.2f}) | runner-up: {rr.get('runner_up_leaf')} ({rr.get('runner_up_p'):.2f})")

    print("\n=== Decision ===")
    print(f"mode: {dec.get('mode')}")
    print(f"chosen: {dec.get('chosen')}")
    if payload.get("ai_final_reasoner", {}).get("used"):
        print(f"final reasoner: {payload['ai_final_reasoner'].get('leaf')}")

    print("\n=== Output ===")
    print(final.get("overlay") or final.get("answer") or "")
    if final.get("details"):
        print("\n--- details ---")
        print(final["details"])

    print("\n(log written to ./logs)\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
