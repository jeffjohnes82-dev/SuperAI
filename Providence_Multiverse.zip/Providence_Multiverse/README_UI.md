# Providence UI (ChatGPT-esque prototype)

## Run

```bash
pip install -r requirements.txt
uvicorn server:app --reload
```

Open `http://127.0.0.1:8000`.

## Debug panel
The right panel shows:
- routing probabilities
- chosen leaves + decision mode
- taxonomy tree (root → branch → leaf)
- verification outcomes (claims + pass/fail)
- Brainchild Mega state (self-evolving controllers)

