"""Evolution Core

This module implements a lightweight, self-evolving policy layer (Population-style)
that tunes a small set of runtime knobs (reject threshold, top_k, verification
strictness, budget scale, confidence cap) using online rewards.

It is intentionally simple and safe: it never edits source code; it only proposes
runtime overrides and persists its state.
"""

from .evolution_core import EvolutionCore
