from __future__ import annotations

import random
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple


@dataclass
class Genome:
    """Small mutation-friendly parameter set."""

    reject_threshold: float
    top_k: int
    verification_strictness: float
    budget_scale: float
    confidence_cap: float
    score_ema: float = 0.0
    n: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "reject_threshold": float(self.reject_threshold),
            "top_k": int(self.top_k),
            "verification_strictness": float(self.verification_strictness),
            "budget_scale": float(self.budget_scale),
            "confidence_cap": float(self.confidence_cap),
            "score_ema": float(self.score_ema),
            "n": int(self.n),
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "Genome":
        return Genome(
            reject_threshold=float(d.get("reject_threshold", 0.5)),
            top_k=int(d.get("top_k", 3)),
            verification_strictness=float(d.get("verification_strictness", 0.5)),
            budget_scale=float(d.get("budget_scale", 1.0)),
            confidence_cap=float(d.get("confidence_cap", 0.95)),
            score_ema=float(d.get("score_ema", 0.0)),
            n=int(d.get("n", 0)),
        )


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


class EvolutionCore:
    """Population-style self-evolving policy tuner.

    Goal: improve overall reward (progress + verified accuracy, while penalizing
    hallucination, cost, and latency) by mutating a small set of runtime knobs.

    NOTE: This is not "AGI training"; it's a practical online optimizer for
    orchestration parameters.
    """

    def __init__(self, cfg: Dict[str, Any], state: Dict[str, Any]):
        self.cfg = cfg or {}
        self.enabled = bool(self.cfg.get("enabled", True))
        self.state = state
        self._active_idx: Optional[int] = None

        self._ensure_state_initialized()

    def _ensure_state_initialized(self) -> None:
        evo = self.state.setdefault("evolution", {})
        evo.setdefault("runs", 0)
        evo.setdefault("last_evolve_ts", 0.0)

        pop = evo.get("population")
        if isinstance(pop, list) and pop:
            return

        pop_size = int(self.cfg.get("population_size", 12))
        elite_size = int(self.cfg.get("elite_size", 3))
        pop_size = max(pop_size, elite_size + 1)

        ranges = self.cfg.get("params", {})
        r_reject = ranges.get("reject_threshold_range", [0.35, 0.70])
        r_strict = ranges.get("verification_strictness_range", [0.25, 0.95])
        r_budget = ranges.get("budget_scale_range", [0.70, 1.60])
        r_cap = ranges.get("confidence_cap_range", [0.75, 1.00])
        r_topk = ranges.get("top_k_range", [1, 5])

        population = []
        for _ in range(pop_size):
            g = Genome(
                reject_threshold=random.uniform(float(r_reject[0]), float(r_reject[1])),
                top_k=random.randint(int(r_topk[0]), int(r_topk[1])),
                verification_strictness=random.uniform(float(r_strict[0]), float(r_strict[1])),
                budget_scale=random.uniform(float(r_budget[0]), float(r_budget[1])),
                confidence_cap=random.uniform(float(r_cap[0]), float(r_cap[1])),
            )
            population.append(g.to_dict())

        evo["population"] = population
        evo["elite_size"] = elite_size

    def start_run(self) -> Optional[int]:
        """Select an active genome for the current run."""
        if not self.enabled:
            self._active_idx = None
            return None

        evo = self.state.setdefault("evolution", {})
        pop_list = evo.get("population") or []
        if not pop_list:
            self._active_idx = None
            return None

        explore_prob = float(self.cfg.get("explore_prob", 0.20))

        # Exploit: pick the best score_ema; Explore: pick random.
        if random.random() < explore_prob:
            idx = random.randrange(len(pop_list))
        else:
            best_score = None
            best_idxs = []
            for i, gd in enumerate(pop_list):
                s = float(gd.get("score_ema", 0.0))
                if best_score is None or s > best_score:
                    best_score = s
                    best_idxs = [i]
                elif s == best_score:
                    best_idxs.append(i)
            idx = random.choice(best_idxs) if best_idxs else 0

        self._active_idx = int(idx)
        evo["active_idx"] = int(idx)
        evo["runs"] = int(evo.get("runs", 0)) + 1
        return self._active_idx

    def get_active_genome(self) -> Optional[Genome]:
        if not self.enabled:
            return None
        evo = self.state.get("evolution", {})
        pop_list = evo.get("population") or []
        idx = self._active_idx
        if idx is None:
            idx = evo.get("active_idx")
        if idx is None:
            return None
        try:
            return Genome.from_dict(pop_list[int(idx)])
        except Exception:
            return None

    def get_overrides(self) -> Dict[str, Any]:
        g = self.get_active_genome()
        if g is None:
            return {}
        return {
            "reject_threshold": g.reject_threshold,
            "top_k": g.top_k,
            "verification_strictness": g.verification_strictness,
            "budget_scale": g.budget_scale,
            "confidence_cap": g.confidence_cap,
            "evolution_active_idx": self._active_idx,
        }

    def update_active_genome(self, reward: float) -> None:
        if not self.enabled:
            return
        evo = self.state.get("evolution", {})
        pop_list = evo.get("population") or []
        idx = self._active_idx
        if idx is None:
            idx = evo.get("active_idx")
        if idx is None or not pop_list:
            return

        i = int(idx)
        gd = dict(pop_list[i])
        n = int(gd.get("n", 0))
        old = float(gd.get("score_ema", 0.0))
        alpha = float(self.cfg.get("score_ema_alpha", 0.12))
        new = (1.0 - alpha) * old + alpha * float(reward)
        gd["score_ema"] = float(new)
        gd["n"] = int(n + 1)
        pop_list[i] = gd
        evo["population"] = pop_list

    def maybe_evolve(self) -> None:
        """Occasionally mutate the population based on scores."""
        if not self.enabled:
            return

        evo = self.state.get("evolution", {})
        pop_list = evo.get("population") or []
        if not pop_list:
            return

        evolve_every = int(self.cfg.get("evolve_every_n", 25))
        runs = int(evo.get("runs", 0))
        if evolve_every <= 0 or (runs % evolve_every) != 0:
            return

        # Sort by score
        genomes = [Genome.from_dict(g) for g in pop_list]
        genomes.sort(key=lambda g: float(g.score_ema), reverse=True)

        elite_size = int(self.cfg.get("elite_size", evo.get("elite_size", 3)))
        elite_size = max(1, min(elite_size, len(genomes) - 1))
        elites = genomes[:elite_size]

        # Ranges and mutation sigmas
        ranges = self.cfg.get("params", {})
        r_reject = ranges.get("reject_threshold_range", [0.35, 0.70])
        r_strict = ranges.get("verification_strictness_range", [0.25, 0.95])
        r_budget = ranges.get("budget_scale_range", [0.70, 1.60])
        r_cap = ranges.get("confidence_cap_range", [0.75, 1.00])
        r_topk = ranges.get("top_k_range", [1, 5])

        mut = self.cfg.get("mutation", {})
        sigma = mut.get("sigma", {})
        s_reject = float(sigma.get("reject_threshold", 0.04))
        s_strict = float(sigma.get("verification_strictness", 0.08))
        s_budget = float(sigma.get("budget_scale", 0.15))
        s_cap = float(sigma.get("confidence_cap", 0.05))
        topk_step_prob = float(mut.get("top_k_step_prob", 0.35))

        def mutate(base: Genome) -> Genome:
            g = Genome(
                reject_threshold=_clamp(base.reject_threshold + random.gauss(0.0, s_reject), float(r_reject[0]), float(r_reject[1])),
                top_k=int(base.top_k),
                verification_strictness=_clamp(base.verification_strictness + random.gauss(0.0, s_strict), float(r_strict[0]), float(r_strict[1])),
                budget_scale=_clamp(base.budget_scale + random.gauss(0.0, s_budget), float(r_budget[0]), float(r_budget[1])),
                confidence_cap=_clamp(base.confidence_cap + random.gauss(0.0, s_cap), float(r_cap[0]), float(r_cap[1])),
                score_ema=0.0,
                n=0,
            )
            if random.random() < topk_step_prob:
                g.top_k = int(_clamp(float(g.top_k + random.choice([-1, 1])), float(r_topk[0]), float(r_topk[1])))
            g.top_k = int(_clamp(float(g.top_k), float(r_topk[0]), float(r_topk[1])))
            return g

        # Rebuild population: keep elites, then fill with mutated elite samples.
        new_pop: list[Genome] = []
        new_pop.extend(elites)
        while len(new_pop) < len(genomes):
            parent = random.choice(elites)
            new_pop.append(mutate(parent))

        evo["population"] = [g.to_dict() for g in new_pop]
        evo["last_evolve_ts"] = time.time()

    @staticmethod
    def compute_reward(
        *,
        progress_obs: float,
        verified_obs: float,
        halluc_obs: float,
        cost_tokens: float,
        latency_seconds: float,
        cost_target: float,
        latency_target: float,
        w_prog: float = 0.58,
        w_acc: float = 0.42,
        penalty_h: float = 1.0,
        penalty_cost: float = 0.05,
        penalty_lat: float = 0.10,
    ) -> float:
        reward = (w_prog * float(progress_obs) + w_acc * float(verified_obs)) - (penalty_h * float(halluc_obs))
        reward -= penalty_cost * (float(cost_tokens) / max(1.0, float(cost_target)))
        reward -= penalty_lat * (float(latency_seconds) / max(0.5, float(latency_target)))
        return float(reward)

