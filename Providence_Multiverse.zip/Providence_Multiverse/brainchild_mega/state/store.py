from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict


DEFAULT_STATE: Dict[str, Any] = {
    "decision": {
        "leaf_stats": {},  # leaf_id -> {n, reward_sum, reward_sq_sum}
        "edge_stats": {},  # edge_key -> {n, reward_sum}
        "total_plays": 0,
    },
    "accuracy": {
        "hallucination_rate_ema": 0.0,
        "verification_strictness": 0.5,  # 0=loose, 1=strict
        "confidence_cap": 0.95,  # cap confidence when hallucination rises
        "calibration_temperature": 1.0,
    },
    "progress": {
        "task_success_rate_ema": 0.0,
        "time_to_first_useful_p50": 0.0,
        "reject_rate_ema": 0.0,
    },
    "scholastic": {
        "subjects": {
            "math": {"elo": 1000.0, "n": 0},
            "physics": {"elo": 1000.0, "n": 0},
            "ai": {"elo": 1000.0, "n": 0},
        }
    },
    "optimization": {
        "lambda_cost": 0.0,
        "lambda_latency": 0.0,
        "lambda_halluc": 0.0,
        "budget_scale": 1.0,
    },
}


@dataclass
class StateStore:
    path: Path

    def load(self) -> Dict[str, Any]:
        if not self.path.exists():
            return json.loads(json.dumps(DEFAULT_STATE))
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            # corrupted state: start fresh
            return json.loads(json.dumps(DEFAULT_STATE))

    def save(self, state: Dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
