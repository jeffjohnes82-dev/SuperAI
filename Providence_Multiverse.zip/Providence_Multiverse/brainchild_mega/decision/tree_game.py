from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from brainchild_mega.decision.bandits import ArmStats, select_thompson_gaussian, select_ucb1
from brainchild_mega.decision.mcts import choose_leaf_mcts


@dataclass
class TraversalChoice:
    path: List[str]          # e.g., ["root", "NatSci", "natsci.physics"]
    leaf_id: str
    mode: str                # ucb1 | thompson | prior_only


def _ensure_leaf_stats(state: Dict[str, Any]) -> Dict[str, ArmStats]:
    raw = state.setdefault("decision", {}).setdefault("leaf_stats", {})
    parsed: Dict[str, ArmStats] = {}
    for k, v in raw.items():
        try:
            parsed[k] = ArmStats(
                n=int(v.get("n", 0)),
                reward_sum=float(v.get("reward_sum", 0.0)),
                reward_sq_sum=float(v.get("reward_sq_sum", 0.0)),
            )
        except Exception:
            parsed[k] = ArmStats()
    return parsed


def _write_back_leaf_stats(state: Dict[str, Any], stats: Dict[str, ArmStats]) -> None:
    raw = state.setdefault("decision", {}).setdefault("leaf_stats", {})
    for k, s in stats.items():
        raw[k] = {"n": s.n, "reward_sum": s.reward_sum, "reward_sq_sum": s.reward_sq_sum}


def choose_leaf(
    priors: Dict[str, float],
    taxonomy: Dict[str, Any],
    state: Dict[str, Any],
    algorithm: str = "ucb1",
    exploration_c: float = 1.2,
) -> TraversalChoice:
    """Choose a leaf to execute.

    priors: leaf_id -> prior probability (router)
    taxonomy: config taxonomy structure; used to build a path root->branch->leaf
    state: persistent mega state (will be mutated)

    Returns a TraversalChoice including the full path.
    """
    if not priors:
        raise ValueError("priors must be non-empty")

    leaf_stats = _ensure_leaf_stats(state)
    total_plays = int(state.setdefault("decision", {}).get("total_plays", 0))

    if algorithm == "mcts":
        leaf_id, meta = choose_leaf_mcts(priors, taxonomy=taxonomy, state=state)
        return TraversalChoice(path=meta.get("path", ["root", leaf_id]), leaf_id=leaf_id, mode=meta.get("mode", "mcts"))

    if algorithm == "prior_only":
        leaf_id = max(priors.items(), key=lambda kv: kv[1])[0]
        mode = "prior_only"
    elif algorithm == "thompson":
        leaf_id = select_thompson_gaussian(priors, leaf_stats)
        mode = "thompson"
    else:
        leaf_id = select_ucb1(priors, leaf_stats, total_plays=total_plays, c=exploration_c)
        mode = "ucb1"

    # increment total plays
    state.setdefault("decision", {})["total_plays"] = total_plays + 1
    _write_back_leaf_stats(state, leaf_stats)

    # build a human-readable path using taxonomy
    path = ["root"]
    branch = _find_branch_for_leaf(taxonomy, leaf_id)
    if branch:
        path.append(branch)
    path.append(leaf_id)

    return TraversalChoice(path=path, leaf_id=leaf_id, mode=mode)


def update_reward(state: Dict[str, Any], leaf_id: str, reward: float) -> None:
    """Update bandit statistics for the chosen leaf."""
    leaf_stats = _ensure_leaf_stats(state)
    s = leaf_stats.get(leaf_id) or ArmStats()
    s.update(float(reward))
    leaf_stats[leaf_id] = s
    _write_back_leaf_stats(state, leaf_stats)


def _find_branch_for_leaf(taxonomy: Dict[str, Any], leaf_id: str) -> Optional[str]:
    # taxonomy expected shape:
    # {"branches": {"NatSci": {"leaves": {"natsci.physics": {...}}}}}
    try:
        branches = taxonomy.get("branches", {})
        for bname, b in branches.items():
            leaves = (b or {}).get("leaves", {})
            if leaf_id in leaves:
                return bname
    except Exception:
        return None
    return None
