from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Dict


@dataclass
class ArmStats:
    n: int = 0
    reward_sum: float = 0.0
    reward_sq_sum: float = 0.0

    def update(self, reward: float) -> None:
        self.n += 1
        self.reward_sum += reward
        self.reward_sq_sum += reward * reward

    @property
    def mean(self) -> float:
        return self.reward_sum / self.n if self.n else 0.0

    @property
    def variance(self) -> float:
        # Conservative variance for exploration when data is scarce.
        if self.n < 2:
            return 1.0
        m = self.mean
        return max(1e-6, self.reward_sq_sum / self.n - m * m)


def _get(stats: Dict[str, ArmStats], arm: str) -> ArmStats:
    if arm not in stats:
        stats[arm] = ArmStats()
    return stats[arm]


def select_ucb1(
    priors: Dict[str, float],
    stats: Dict[str, ArmStats],
    total_plays: int,
    c: float = 1.2,
    prior_weight: float = 0.25,
) -> str:
    """UCB1 with a weak prior term.

    priors: router probabilities (0..1)
    stats: empirical rewards
    total_plays: total selections across all arms

    Returns: selected arm id.
    """
    total_plays = max(1, int(total_plays))
    best_arm = None
    best_score = -1e18

    for arm, prior in priors.items():
        s = _get(stats, arm)
        if s.n == 0:
            bonus = float('inf')
        else:
            bonus = c * math.sqrt(math.log(total_plays) / s.n)
        score = s.mean + bonus + prior_weight * float(prior)
        if score > best_score:
            best_score = score
            best_arm = arm

    # Fallback (shouldn't happen)
    return best_arm or max(priors.items(), key=lambda kv: kv[1])[0]


def select_thompson_gaussian(
    priors: Dict[str, float],
    stats: Dict[str, ArmStats],
    prior_mean_scale: float = 0.25,
) -> str:
    """Thompson sampling with a simple Gaussian posterior approximation.

    This is a lightweight stand-in for more complex contextual bandits.
    """
    best_arm = None
    best_sample = -1e18

    for arm, prior in priors.items():
        s = _get(stats, arm)
        # Posterior mean starts at scaled prior; then drifts to empirical mean.
        mu0 = prior_mean_scale * float(prior)
        if s.n == 0:
            mu = mu0
            sigma = 1.0
        else:
            mu = (mu0 + s.mean) / 2.0
            sigma = math.sqrt(s.variance / max(1, s.n))
        sample = random.gauss(mu, sigma)
        if sample > best_sample:
            best_sample = sample
            best_arm = arm

    return best_arm or max(priors.items(), key=lambda kv: kv[1])[0]
