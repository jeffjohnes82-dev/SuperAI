# Expanding Universe Theory (Providence Multiverse)

This build includes a dedicated leaf **`natsci.expanding_universe`** to cover the
core "expanding universe" framework used in modern cosmology.

## What it covers

- **Metric expansion of space** (the FLRW space-time, scale factor *a(t)*)
- **Hubble–Lemaître law** (*v ≈ H₀ d* at low redshift)
- **Redshift and scale factor** (*1 + z = a₀ / a*)
- **Expansion history** (*H(z)*) and the **Friedmann equations**
- **Evidence:** galaxy redshifts, CMB, baryon acoustic oscillations (BAO), Type Ia supernovae,
  and primordial nucleosynthesis
- **Acceleration:** dark energy / cosmological constant (Λ) as the standard parameterization
- **Open problems:** e.g. the "Hubble tension" (ongoing)

## How it connects to the Multiverse module

The Multiverse mode remains **theoretical-only** (no claims of real access to
other universes). The expanding-universe leaf is used to ground any multiverse
discussion in the best-established cosmological context (ΛCDM + inflationary
expansion scenarios).

## Usage examples

- "Explain what it means that the universe is expanding."
- "How does redshift relate to the scale factor?"
- "What is the Hubble constant and why is there a Hubble tension?"
- "How does accelerated expansion relate to dark energy?"
