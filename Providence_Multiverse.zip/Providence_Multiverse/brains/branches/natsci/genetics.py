from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class GeneticsBrain(TemplateBrain):
    """Specialist brain for natsci.genetics."""

    def __init__(self):
        super().__init__(
            name="natsci.genetics",
            specialty="natsci / genetics",
            checklist=['Clarify system and assumptions', 'Use scientific method: model → prediction → check', 'Provide mechanism + next steps'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
