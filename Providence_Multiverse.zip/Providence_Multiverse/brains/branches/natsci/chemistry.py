from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class ChemistryBrain(TemplateBrain):
    """Specialist brain for natsci.chemistry."""

    def __init__(self):
        super().__init__(
            name="natsci.chemistry",
            specialty="natsci / chemistry",
            checklist=['Identify species/reaction', 'Balance equations if needed', 'Use stoichiometry/thermo as appropriate', 'Check units and assumptions'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
