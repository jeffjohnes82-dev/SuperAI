from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class ExpandingUniverseBrain(TemplateBrain):
    """Specialist brain for natsci.expanding_universe.

    Scope: the expanding universe framework in modern cosmology (FLRW metric,
    Hubble–Lemaître law, redshift–distance relation, expansion history, and
    acceleration).

    Notes:
    - This prototype brain is intentionally lightweight (TemplateBrain) so it
      works offline with no external model dependency.
    - It is meant to be used in the Multiverse build as the "expansion" lens
      alongside cosmology/multiverse-theory leaves.
    """

    def __init__(self):
        super().__init__(
            name="natsci.expanding_universe",
            specialty=(
                "natsci / expanding universe (FLRW, redshift, Hubble expansion, "
                "ΛCDM expansion history)"
            ),
            checklist=[
                "Clarify what the user means by 'expansion' (space-time metric vs objects moving through space)",
                "State the standard framework: FLRW metric + scale factor a(t)",
                "Link observables to expansion: redshift z, luminosity/angle distances, H(z)",
                "Summarize key evidence: galaxy redshifts, CMB, BAO, primordial nucleosynthesis",
                "If asked about acceleration, introduce dark energy/Λ and distinguish evidence from speculation",
                "Where helpful, include the core relations: v≈H0 d (low-z), 1+z=a0/a, Friedmann equations",
                "Flag current open problems (e.g., Hubble tension) as unresolved",
            ],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
