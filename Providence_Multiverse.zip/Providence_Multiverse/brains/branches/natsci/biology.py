from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class BiologyBrain(TemplateBrain):
    """Specialist brain for natsci.biology."""

    def __init__(self):
        super().__init__(
            name="natsci.biology",
            specialty="natsci / biology",
            checklist=['Identify organism/system level', 'Name mechanisms/processes', 'State assumptions and evidence', 'Propose tests or next steps'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
