from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class MathematicsBrain(TemplateBrain):
    """Specialist brain for forsci.mathematics."""

    def __init__(self):
        super().__init__(
            name="forsci.mathematics",
            specialty="forsci / mathematics",
            checklist=['Restate problem precisely', 'Choose method (algebra/calculus/etc.)', 'Work step-by-step', 'Check result/edge cases'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
