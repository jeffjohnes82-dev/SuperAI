from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class InformationTheoryBrain(TemplateBrain):
    """Specialist brain for forsci.information_theory."""

    def __init__(self):
        super().__init__(
            name="forsci.information_theory",
            specialty="forsci / information_theory",
            checklist=['Define objects and constraints', 'Choose formal method', 'Work cleanly and check edge cases'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
