from __future__ import annotations

from brains.base import TemplateBrain


class GeneralBrain(TemplateBrain):
    """AI branch general specialist (theory + systems)."""

    def __init__(self):
        super().__init__(
            name="ai.general",
            specialty="AI general (ML/LLMs/agents/evaluation)",
            checklist=[
                "Restate the goal and constraints",
                "Identify the AI subproblem (ML/LLM/RL/agents/eval)",
                "Choose an approach and assumptions",
                "Provide solution steps with sanity checks",
                "Suggest next experiments or implementation steps",
            ],
        )
