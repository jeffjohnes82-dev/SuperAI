from __future__ import annotations

from brains.base import TemplateBrain


class ReinforcementLearningBrain(TemplateBrain):
    """RL specialist."""

    def __init__(self):
        super().__init__(
            name="ai.reinforcement_learning",
            specialty="Reinforcement learning (MDPs, policies, reward design)",
            checklist=[
                "Define state/action space and reward",
                "Choose algorithm family (value-based/policy-gradient/model-based)",
                "Specify exploration and stability tricks",
                "Simulate, tune hyperparameters, and check sample efficiency",
                "Evaluate robustness and failure cases",
            ],
        )
