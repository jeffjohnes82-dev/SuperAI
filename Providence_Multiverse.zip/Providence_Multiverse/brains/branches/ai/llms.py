from __future__ import annotations

from brains.base import TemplateBrain


class LlmsBrain(TemplateBrain):
    """LLM specialist."""

    def __init__(self):
        super().__init__(
            name="ai.llms",
            specialty="Large language models (prompting, RAG, fine-tuning, evals)",
            checklist=[
                "Clarify target behavior and constraints (latency/cost/safety)",
                "Pick approach: prompting, RAG, fine-tuning, tool-use, or hybrid",
                "Define data/retrieval pipeline and context limits",
                "Design evaluation (quality, hallucination, grounding, regression)",
                "Iterate with ablations and deploy with monitoring",
            ],
        )
