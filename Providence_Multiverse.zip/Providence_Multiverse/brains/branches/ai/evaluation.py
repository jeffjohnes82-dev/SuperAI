from __future__ import annotations

from brains.base import TemplateBrain


class EvaluationBrain(TemplateBrain):
    """Model evaluation specialist."""

    def __init__(self):
        super().__init__(
            name="ai.evaluation",
            specialty="AI evaluation (benchmarks, calibration, hallucination control)",
            checklist=[
                "Define task categories and success metrics",
                "Create a representative evaluation set (incl. hard negatives)",
                "Measure accuracy, calibration, and hallucination/grounding",
                "Add regression tests and track drift over time",
                "Tune thresholds/budgets using the eval results",
            ],
        )
