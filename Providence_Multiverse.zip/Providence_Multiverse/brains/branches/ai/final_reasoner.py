from __future__ import annotations

from typing import Any, Dict, List

from brains.base import Brain
from master.types import BrainOutput


def _score_candidate(o: Dict[str, Any]) -> float:
    """Prefer verified outputs, then confidence."""
    v = o.get("verified_score")
    try:
        vs = float(v) if v is not None else 0.0
    except Exception:
        vs = 0.0
    try:
        conf = float(o.get("confidence", 0.0))
    except Exception:
        conf = 0.0

    can_finalize = bool(o.get("can_finalize", True))
    bonus = 0.15 if can_finalize else 0.0
    return (2.0 * vs) + conf + bonus


class FinalReasonerBrain:
    """Final synthesis pass.

    This is an in-house deterministic "reasoner": it chooses the best candidate
    leaf output and produces a consolidated final answer. If an API backend is
    enabled later, you can swap this for a model-based synthesizer.
    """

    name: str = "ai.final_reasoner"

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        candidates: List[Dict[str, Any]] = list(context.get("candidate_outputs") or [])
        candidate_final: Dict[str, Any] | None = context.get("candidate_final")
        strictness = float(context.get("verification_strictness", 0.5) or 0.5)

        # If we have a merged candidate, treat it as another option.
        if candidate_final:
            candidates = candidates + [candidate_final]

        if not candidates:
            return {
                "brain": self.name,
                "confidence": 0.55,
                "overlay": "No candidate solution was produced.",
                "details": "Try rephrasing with clearer constraints.",
                "final": False,
                "claims": [],
                "verifications": [],
                "metadata": {"budget": budget},
            }

        ranked = sorted(candidates, key=_score_candidate, reverse=True)
        best = ranked[0]
        best_brain = best.get("brain", "?")

        overlay = best.get("overlay") or best.get("answer") or ""
        details_parts = []
        details_parts.append(f"[ai.final_reasoner] selected={best_brain} budget={budget} strictness={strictness:.2f}")

        # Provide a compact "reasoning summary" without exposing hidden chain-of-thought:
        details_parts.append("synthesis:")
        details_parts.append("- Used the highest-scoring candidate based on verification and confidence.")
        if len(ranked) > 1:
            others = ", ".join(str(o.get("brain", "?")) for o in ranked[1:4])
            details_parts.append(f"- Compared against alternatives: {others}")

        if best.get("details"):
            details_parts.append("\nselected-details:\n" + str(best.get("details")))

        out: BrainOutput = {
            "brain": self.name,
            "confidence": min(0.90, float(best.get("confidence", 0.6)) + 0.05),
            "overlay": overlay,
            "details": "\n".join(details_parts),
            "final": True,
            # Pass through candidate claims/verifs so the verification gate can act on them.
            "claims": list(best.get("claims") or []),
            "verifications": list(best.get("verifications") or []),
            "metadata": {
                "selected": best_brain,
                "ranked_brains": [o.get("brain", "?") for o in ranked[:6]],
            },
        }

        # If strictness is high and we see verification failures already, do not assert final.
        if strictness >= 0.70:
            fails = [v for v in out.get("verifications") or [] if isinstance(v, dict) and v.get("status") == "fail"]
            if fails:
                out["final"] = False
                out["confidence"] = min(float(out.get("confidence", 0.6)), 0.55)
                out["overlay"] = "Verification failures detected — need more grounding before finalizing."

        return out
