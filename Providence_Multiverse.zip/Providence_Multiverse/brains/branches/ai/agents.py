from __future__ import annotations

from brains.base import TemplateBrain


class AgentsBrain(TemplateBrain):
    """Agentic systems specialist."""

    def __init__(self):
        super().__init__(
            name="ai.agents",
            specialty="Agentic systems (planning, tool use, multi-agent orchestration)",
            checklist=[
                "Define objectives, constraints, and success criteria",
                "Design toolset and permissions (what can be called and when)",
                "Pick architecture: single-agent, planner-executor, or multi-agent",
                "Add memory and state management with guardrails",
                "Evaluate with scenario tests and monitor failures",
            ],
        )
