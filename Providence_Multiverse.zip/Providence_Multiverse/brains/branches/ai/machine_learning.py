from __future__ import annotations

from brains.base import TemplateBrain


class MachineLearningBrain(TemplateBrain):
    """ML specialist."""

    def __init__(self):
        super().__init__(
            name="ai.machine_learning",
            specialty="Machine learning (modeling, features, training, validation)",
            checklist=[
                "Define task type (classification/regression/etc.) and data schema",
                "Choose baseline + metrics + validation split",
                "Select model family and regularization",
                "Train, check leakage, and tune",
                "Report results and next improvements",
            ],
        )
