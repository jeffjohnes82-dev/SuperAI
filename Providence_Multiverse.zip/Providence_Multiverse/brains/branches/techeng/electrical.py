from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class ElectricalBrain(TemplateBrain):
    """Specialist brain for techeng.electrical."""

    def __init__(self):
        super().__init__(
            name="techeng.electrical",
            specialty="techeng / electrical",
            checklist=['Identify circuit/model', 'Apply KCL/KVL/Ohm', 'Compute and check units', 'Validate against constraints'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
