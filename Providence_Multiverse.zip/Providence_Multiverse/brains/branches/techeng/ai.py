from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class AiBrain(TemplateBrain):
    """Specialist brain for techeng.ai."""

    def __init__(self):
        super().__init__(
            name="techeng.ai",
            specialty="techeng / ai",
            checklist=['Clarify task/data/metric', 'Pick baselines', 'Model/training plan', 'Eval, failure modes, iteration loop'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
