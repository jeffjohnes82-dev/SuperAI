from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class RoboticsBrain(TemplateBrain):
    """Specialist brain for techeng.robotics."""

    def __init__(self):
        super().__init__(
            name="techeng.robotics",
            specialty="techeng / robotics",
            checklist=['Clarify requirements', 'Design solution', 'Consider constraints (cost/latency/safety)', 'Test and iterate'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
