from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class SoftwareEngineeringBrain(TemplateBrain):
    """Specialist brain for techeng.software_engineering."""

    def __init__(self):
        super().__init__(
            name="techeng.software_engineering",
            specialty="techeng / software_engineering",
            checklist=['Clarify requirements/constraints', 'Sketch architecture and interfaces', 'Testing and observability plan', 'Deployment and reliability considerations'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
