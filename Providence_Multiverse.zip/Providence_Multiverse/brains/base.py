from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Protocol

from master.types import BrainOutput


class Brain(Protocol):
    """Interface for specialist brains."""

    name: str

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        ...


@dataclass
class TemplateBrain:
    """A simple brain that formats responses using a playbook.

    This is intentionally lightweight: it makes the routing demo "feel"
    specialized without any model dependencies.
    """

    name: str
    specialty: str
    checklist: List[str]

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        overlay = f"[{self.name}] {self.specialty}: {query}"
        details_lines = [
            f"[{self.name}] specialty: {self.specialty}",
            f"budget={budget}",
            "playbook:",
            *[f"- {item}" for item in self.checklist],
        ]
        return {
            "brain": self.name,
            "confidence": 0.65,
            "overlay": overlay,
            "details": "\n".join(details_lines),
            "claims": [],
            "verifications": [],
            "final": False,
            "metadata": {"context_keys": sorted(list(context.keys()))},
        }
