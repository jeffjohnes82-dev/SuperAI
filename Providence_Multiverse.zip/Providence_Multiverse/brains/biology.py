from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class BiologyBrain(TemplateBrain):
    """Biology specialist brain."""

    def __init__(self):
        super().__init__(
            name="biology",
            specialty="biology (cells, systems, evolution, and mechanisms)",
            checklist=[
                "Identify the biological level (molecular/cellular/tissue/organism/ecosystem)",
                "Name the key structures and functions involved",
                "Explain the causal mechanism (pathway, feedback loop, selection pressure)",
                "Note typical timescales and constraints (energy, resources, signaling)",
                "If applicable, connect phenotype ↔ genotype and environment",
                "Provide a concrete example and common misconceptions",
            ],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
