from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

from verifiers.claim_extractor import extract_claims
from verifiers.math_verifier import verify_math_claim
from verifiers.unit_verifier import verify_unit_claim


@dataclass
class VerificationSummary:
    claims: List[Dict[str, Any]]
    verifications: List[Dict[str, Any]]
    verified_score: float  # 0..1
    hallucination_estimate: float  # 0..1
    can_finalize: bool
    reason: str


def _aggregate(results: List[Dict[str, Any]]) -> Tuple[int, int, int]:
    p = sum(1 for r in results if r.get("status") == "pass")
    f = sum(1 for r in results if r.get("status") == "fail")
    u = sum(1 for r in results if r.get("status") == "unknown")
    return p, f, u


def verify_output(
    *,
    query: str,
    domain: str,
    output: Dict[str, Any],
    strictness: float,
) -> VerificationSummary:
    """Apply verification according to verification_strictness.

    strictness controls:
      - <0.35: only verify math/physics claims if present
      - 0.35..0.70: verify math/physics + fail if evidence_required facts appear
      - >=0.70: strict; any fail blocks finalization
    """
    text = (output.get("details") or output.get("overlay") or output.get("answer") or "").strip()
    claims = list(output.get("claims") or [])
    if not claims:
        claims = extract_claims(query=query, output_text=text, domain=domain, strictness=strictness)

    results: List[Dict[str, Any]] = []
    for c in claims:
        ctype = c.get("type")
        if ctype == "math":
            results.append(verify_math_claim(c))
        elif ctype == "physics":
            results.append(verify_unit_claim(c))
        elif ctype == "fact" and strictness >= 0.35:
            if bool(c.get("evidence_required", False)):
                results.append(
                    {
                        "claim_id": c.get("id"),
                        "status": "fail",
                        "reason": "evidence required but not provided (v1)",
                        "evidence": None,
                    }
                )
        else:
            # Unknown verifier type
            results.append({"claim_id": c.get("id"), "status": "unknown", "reason": "no verifier"})

    passed, failed, unknown = _aggregate(results)

    # Verified score: treat pass=1, unknown=0.5, fail=0
    n = max(1, len(results))
    verified_score = (passed + 0.5 * unknown) / n

    # Hallucination estimate: high confidence + fail is bad; strictness increases sensitivity.
    conf = float(output.get("confidence", 0.0))
    hallu = 0.0
    if failed > 0 and conf >= 0.8:
        hallu = min(0.35, 0.05 * failed + 0.05 * (1.0 if strictness >= 0.70 else 0.5))
    elif failed > 0:
        hallu = min(0.20, 0.03 * failed)

    # Finalization policy
    if failed == 0:
        can_finalize = True
        reason = "all checks passed/unknown"
    else:
        if strictness >= 0.70:
            can_finalize = False
            reason = f"blocked by {failed} verification fail(s) (strict mode)"
        elif strictness >= 0.35 and failed >= 2:
            can_finalize = False
            reason = f"blocked by {failed} verification fail(s)"
        else:
            can_finalize = True
            reason = f"allowed despite {failed} fail(s) (low strictness)"

    return VerificationSummary(
        claims=claims,
        verifications=results,
        verified_score=float(verified_score),
        hallucination_estimate=float(hallu),
        can_finalize=bool(can_finalize),
        reason=reason,
    )
