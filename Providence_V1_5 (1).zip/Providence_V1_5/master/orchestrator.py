from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

from master.types import BrainOutput, RouteResult

from brainchild_mega import MegaSystem


@dataclass
class Decision:
    mode: str
    chosen_brains: List[str]
    meta: Dict[str, Any] | None = None


class MasterBrain:
    """Total-control orchestrator: routes, budgets, merges, logs."""

    def __init__(self, config: Dict[str, Any], log_dir: str | Path = "logs"):
        self.cfg = config
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)

        # Brainchild Mega: self-evolving control layer (optional).
        self.mega = MegaSystem(self.cfg)

        th = self.cfg["routing_policy"]["thresholds"]
        self.reject_below = float(th["reject_if_top_p_below"])
        self.exclusive_at_least = float(th["exclusive_if_top_p_at_least"])
        self.multi_low = float(th["multi_brain_if_between"]["low"])
        self.multi_high = float(th["multi_brain_if_between"]["high"])

        mb = self.cfg["routing_policy"]["multi_brain"]
        self.top_k = int(mb.get("top_k", 3))
        self.min_domain_prob = float(mb.get("min_domain_prob", 0.10))

        abst = self.cfg["routing_policy"].get("abstain_behavior", {})
        self.reject_message = abst.get("reject_message", "Not worth the resources.")
        self.clarify_band = abst.get("clarify_band", {"enabled": False})

    def decide(self, rr: RouteResult) -> Decision:
        p = rr.top_p

        # Apply self-evolving overrides (does not modify base config).
        reject_below = self.reject_below
        top_k = self.top_k
        if self.mega.enabled:
            ov = self.mega.compute_overrides(base_reject_threshold=self.reject_below, base_top_k=self.top_k)
            if ov.reject_threshold is not None:
                reject_below = float(ov.reject_threshold)
            if ov.top_k is not None:
                top_k = int(ov.top_k)

        if p < reject_below:
            # optional clarify band (still returns a reject-ish mode but different message upstream)
            if self.clarify_band.get("enabled") and self.clarify_band.get("low", 0) <= p <= self.clarify_band.get("high", 0):
                return Decision(mode="clarify", chosen_brains=[])
            return Decision(mode="reject", chosen_brains=[])

        if p >= self.exclusive_at_least:
            return Decision(mode="exclusive", chosen_brains=[rr.top_domain])

        # multi-brain: take top-k with min prob
        sorted_probs = sorted(rr.probs.items(), key=lambda kv: kv[1], reverse=True)
        candidate = {d: float(prob) for d, prob in sorted_probs if float(prob) >= self.min_domain_prob}

        # Self-evolving traversal/game: choose leaves with a bandit policy when enabled.
        meta: Dict[str, Any] | None = None
        if self.mega.enabled and candidate:
            taxonomy = self.cfg.get("taxonomy", {"branches": {}})
            chosen: List[str] = []
            chosen_meta: List[Dict[str, Any]] = []
            priors = dict(candidate)
            # pick sequentially without replacement
            for _ in range(min(top_k, len(priors))):
                leaf_id, m = self.mega.choose_leaf(leaf_priors=priors, taxonomy=taxonomy)
                chosen.append(leaf_id)
                chosen_meta.append({"leaf": leaf_id, **m})
                priors.pop(leaf_id, None)
            meta = {"chosen_by": "brainchild_mega", "choices": chosen_meta}
            return Decision(mode="multi", chosen_brains=chosen or [rr.top_domain], meta=meta)

        chosen = [d for d, prob in sorted_probs[: top_k] if float(prob) >= self.min_domain_prob]
        return Decision(mode="multi", chosen_brains=chosen or [rr.top_domain], meta=meta)

    def merge(self, decision: Decision, outputs: List[BrainOutput], rr: RouteResult) -> BrainOutput:
        confidence_cap = None
        if self.mega.enabled:
            confidence_cap = float(self.mega.state.get("accuracy", {}).get("confidence_cap", 1.0))

        def _agg_verification(out_list: List[BrainOutput]) -> Dict[str, Any]:
            claims: List[Dict[str, Any]] = []
            verifs: List[Dict[str, Any]] = []
            hallu = 0.0
            scores: List[float] = []
            for o in out_list:
                claims.extend(list(o.get("claims") or []))
                verifs.extend(list(o.get("verifications") or []))
                hallu = max(hallu, float(o.get("hallucination_estimate", 0.0) or 0.0))
                if o.get("verified_score") is not None:
                    try:
                        scores.append(float(o.get("verified_score")))
                    except Exception:
                        pass
            verified_score = float(sum(scores) / len(scores)) if scores else None
            fails = sum(1 for v in verifs if v.get("status") == "fail")
            verified = (fails == 0) and (verified_score is None or verified_score >= 0.80)
            return {
                "claims": claims,
                "verifications": verifs,
                "verified_score": verified_score,
                "verified": bool(verified),
                "hallucination_estimate": float(hallu),
            }

        if decision.mode in {"exclusive"} and outputs:
            # add overlay/details if missing
            out = dict(outputs[0])
            out.setdefault("overlay", out.get("answer", ""))
            out.setdefault("details", out.get("answer", ""))
            out.update(_agg_verification([out]))
            if confidence_cap is not None:
                out["confidence"] = min(float(out.get("confidence", rr.top_p)), confidence_cap)
            return out

        if decision.mode in {"multi"} and outputs:
            # very simple merge for mockup: rank by confidence and join
            ranked = sorted(outputs, key=lambda o: float(o.get("confidence", 0.0)), reverse=True)
            overlay = ranked[0].get("overlay") or ranked[0].get("answer", "")
            details = "\n\n".join(
                f"- {o.get('brain','?')}: {(o.get('overlay') or o.get('answer') or '').strip()}" for o in ranked
            )
            merged = {
                "brain": "master",
                "confidence": min(float(rr.top_p), confidence_cap) if confidence_cap is not None else float(rr.top_p),
                "overlay": overlay,
                "details": f"[merge mode={decision.mode} top={rr.top_domain}:{rr.top_p:.2f}]\n{details}",
            }
            merged.update(_agg_verification(outputs))
            return merged

        # clarify/reject
        if decision.mode == "clarify":
            return {
                "brain": "master",
                "confidence": float(rr.top_p),
                "overlay": "I need one detail to answer efficiently.",
                "details": "Please rephrase with: (1) your goal, (2) any constraints, (3) what you already tried.",
            }
        return {
            "brain": "master",
            "confidence": float(rr.top_p),
            "overlay": self.reject_message,
            "details": f"Rejected because top domain confidence {rr.top_p:.2f} < {self.reject_below:.2f}.",
        }

    def log_run(self, payload: Dict[str, Any]) -> None:
        ts = time.strftime("%Y%m%d-%H%M%S")
        path = self.log_dir / f"run-{ts}.json"
        path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
