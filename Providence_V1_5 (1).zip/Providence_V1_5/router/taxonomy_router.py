from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

from master.types import RouteResult


def _normalize(scores: Dict[str, float]) -> Dict[str, float]:
    s = sum(max(0.0, float(v)) for v in scores.values())
    if s <= 0.0:
        n = len(scores) or 1
        return {k: 1.0 / n for k in scores}
    return {k: max(0.0, float(v)) / s for k, v in scores.items()}


def _count_hits(q: str, words: List[str]) -> int:
    q = q.lower()
    return sum(1 for w in words if w in q)


class TaxonomyRouter:
    """Heuristic router over taxonomy leaf ids like 'natsci.physics'.

    It uses keyword maps keyed by leaf *suffix* (e.g. 'physics') so you can
    keep adding new leaves without changing code; unknown leaves get a small
    prior and rely on branch/general.
    """

    def __init__(self, leaf_ids: List[str], taxonomy: Dict[str, Any] | None = None):
        self.leaf_ids = leaf_ids
        self.taxonomy = taxonomy or {"branches": {}}
        self.kw = self._build_keyword_map()

    def _build_keyword_map(self) -> Dict[str, List[str]]:
        return {
            # NatSci
            "physics": [
                "physics", "quantum", "relativity", "entanglement", "force", "energy", "momentum",
                "gravity", "thermodynamics", "optics", "mechanics", "electromagnet", "photon",
            ],
            "chemistry": [
                "chemistry", "molecule", "reaction", "stoichiometry", "molar", "molarity", "acid", "base",
                "pka", "oxidation", "bond", "periodic", "organic", "covalent", "ionic",
            ],
            "biology": [
                "biology", "cell", "enzyme", "dna", "rna", "protein", "evolution", "organism", "microbiology",
            ],
            "earth_science": ["geology", "earth science", "plate", "tectonic", "volcano", "seismic", "rock", "mineral"],
            "astronomy": ["astronomy", "telescope", "galaxy", "star", "planet", "orbit", "cosmology", "exoplanet"],
            "ecology": ["ecosystem", "ecology", "population", "habitat", "biodiversity", "food web"],
            "genetics": ["genetics", "allele", "genome", "chromosome", "mutation", "inheritance", "sequencing"],
            "neuroscience": ["neuron", "brain", "synapse", "neuroscience", "cortex", "dopamine", "action potential"],

            # ForSci
            "mathematics": ["math", "theorem", "proof", "integral", "derivative", "algebra", "matrix", "vector"],
            "discrete_math": ["graph", "combinatorics", "discrete", "set", "bijection", "pigeonhole"],
            "statistics": ["regression", "p-value", "bayesian", "distribution", "variance", "confidence interval"],
            "logic": ["logic", "propositional", "predicate", "truth table", "entails", "modus"],
            "computer_science": ["algorithm", "data structure", "runtime", "complexity", "compiler", "operating system"],
            "optimization": ["optimize", "convex", "gradient", "lagrangian", "constraint", "solver"],
            "information_theory": ["entropy", "mutual information", "information theory", "channel", "coding theorem"],
            "complexity_theory": ["p vs np", "np-hard", "reduction", "complexity class"],

            # TechEng
            "civil": ["beam", "concrete", "bridge", "foundation", "soil", "structural"],
            "mechanical": ["stress", "strain", "torque", "gear", "bearing", "fluid", "cad"],
            "electrical": ["circuit", "voltage", "current", "resistor", "capacitor", "ohm", "impedance"],
            "aerospace": ["aerodynamics", "lift", "drag", "rocket", "orbital", "airfoil", "re-entry"],
            "software_engineering": ["architecture", "microservice", "refactor", "unit test", "deployment", "scalability"],
            "ai": ["machine learning", "neural", "transformer", "llm", "backprop", "training", "inference"],
            # AI branch leaves
            "machine_learning": ["supervised", "unsupervised", "classification", "regression", "feature", "overfitting"],
            "llms": ["llm", "prompt", "rag", "retrieval", "fine-tune", "token", "context window"],
            "reinforcement_learning": ["reinforcement", "policy", "reward", "q-learning", "ppo", "actor-critic"],
            "agents": ["agent", "tool use", "planner", "plan", "execute", "reflection"],
            "evaluation": ["eval", "benchmark", "calibration", "hallucination", "regression test"],
            "cybersecurity": ["threat model", "encryption", "malware", "vulnerability", "auth", "owasp"],
            "data_engineering": ["etl", "pipeline", "warehouse", "lakehouse", "spark", "airflow"],
            "robotics": ["robot", "slam", "trajectory", "kinematics", "actuator", "perception"],
            "controls": ["controller", "pid", "stability", "transfer function", "state-space"],
            "embedded_systems": ["mcu", "firmware", "rtos", "i2c", "spi", "gpio"],
            "materials_engineering": ["alloy", "microstructure", "fatigue", "fracture", "heat treatment"],
            "biomedical_engineering": ["biomedical", "biocompatible", "prosthetic", "ecg", "medical device"],
            "chemical_engineering": ["unit operation", "distillation", "reactor", "mass balance", "heat exchanger"],
            "devops": ["ci/cd", "cicd", "kubernetes", "terraform", "monitoring", "sre"],
        }

    def route(self, query: str) -> RouteResult:
        q = (query or "").lower()
        scores: Dict[str, float] = {leaf: 0.01 for leaf in self.leaf_ids}

        for leaf in self.leaf_ids:
            suffix = leaf.split(".")[-1]
            words = self.kw.get(suffix)
            if words:
                scores[leaf] += float(_count_hits(q, words))

        # boosts
        if any(ch.isdigit() for ch in q):
            for leaf in self.leaf_ids:
                if leaf.endswith("mathematics") or leaf.endswith("statistics") or leaf.endswith("physics"):
                    scores[leaf] += 0.25
        if any(tok in q for tok in ["def ", "class ", "{", "}", "->", "="]):
            for leaf in self.leaf_ids:
                if leaf.endswith("software_engineering") or leaf.endswith("computer_science") or leaf.endswith("ai"):
                    scores[leaf] += 0.25

        probs = _normalize({k: (v ** 1.4) for k, v in scores.items()})

        sorted_items = sorted(probs.items(), key=lambda kv: kv[1], reverse=True)
        (top_domain, top_p) = sorted_items[0]
        (runner_up_domain, runner_up_p) = sorted_items[1] if len(sorted_items) > 1 else (top_domain, 0.0)

        return RouteResult(
            probs=probs,
            top_domain=top_domain,
            top_p=float(top_p),
            runner_up_domain=runner_up_domain,
            runner_up_p=float(runner_up_p),
        )
