from __future__ import annotations

from typing import Dict, List

from master.types import RouteResult


DOMAINS_DEFAULT: List[str] = [
    "physics",
    "chemistry",
    "biology",
    "science",
    "math",
    "statistics",
    "logic",
    "coding",
    "ai",
    "software_engineering",
    "electrical",
    "mechanical",
    "civil",
    "aerospace",
    "planning",
    "research",
    "writing",
    "general",
]


def _normalize(probs: Dict[str, float]) -> Dict[str, float]:
    s = sum(max(v, 0.0) for v in probs.values())
    if s <= 0:
        n = len(probs) or 1
        return {k: 1.0 / n for k in probs}
    return {k: max(v, 0.0) / s for k, v in probs.items()}


def _count_hits(q: str, words: List[str]) -> int:
    return sum(1 for w in words if w in q)


class HeuristicRouter:
    """Keyword scorer router (supports many domains).

    This is intentionally simple but more flexible than if/elif.
    It produces a probability distribution over configured domains.
    """

    def __init__(self, domains: List[str] | None = None):
        self.domains = domains or DOMAINS_DEFAULT

    def route(self, query: str) -> RouteResult:
        q = (query or "").lower()
        scores: Dict[str, float] = {d: 0.0 for d in self.domains}

        kw = {
            "physics": [
                "physics", "quantum", "relativity", "entanglement", "force", "energy", "electron", "photon",
                "gravity", "thermodynamics", "optics", "mechanics", "electromagnet", "wave", "momentum",
            ],
            "chemistry": [
                "chemistry", "molecule", "reaction", "stoichiometry", "molar", "molarity", "acid", "base", "ph ",
                "pka", "oxidation", "bond", "periodic", "organic", "covalent", "ionic",
            ],
            "biology": [
                "biology", "cell", "enzyme", "dna", "rna", "protein", "genetics", "evolution", "neuron", "immune",
                "microbiology", "mitochondria", "metabolism", "organism",
            ],
            "science": ["science", "experiment", "hypothesis", "model", "theory", "data", "lab"],
            "math": ["integral", "derivative", "theorem", "proof", "matrix", "eigen", "calculus", "algebra"],
            "statistics": [
                "regression", "distribution", "anova", "p-value", "p value", "bayesian", "chi-square", "chi square",
                "standard deviation", "variance", "confidence interval", "hypothesis test",
            ],
            "logic": ["logic", "propositional", "predicate", "truth table", "syllogism", "modus", "entails"],
            "coding": ["python", "typescript", "javascript", "bug", "compile", "api", "stack trace", "docker", "git"],
            "ai": [
                "machine learning", "neural", "transformer", "deep learning", "reinforcement", "llm", "agent", "ai ",
                "backprop", "gradient", "training", "inference",
            ],
            "software_engineering": [
                "architecture", "microservice", "refactor", "unit test", "ci/cd", "cicd", "scalability", "design pattern",
                "codebase", "deployment",
            ],
            "electrical": ["circuit", "voltage", "current", "resistor", "capacitor", "ohm", "pcb", "impedance"],
            "mechanical": ["torque", "gear", "stress", "strain", "bearing", "fluid", "pump", "thermo", "cad"],
            "civil": ["concrete", "beam", "bridge", "foundation", "soil", "structural", "rebar"],
            "aerospace": ["aerodynamics", "lift", "drag", "rocket", "orbital", "re-entry", "airfoil"],
            "planning": ["plan", "roadmap", "schedule", "milestone", "prioritize", "timeline", "steps"],
            "research": ["sources", "cite", "paper", "study", "compare", "evidence", "latest"],
            "writing": ["rewrite", "tone", "email", "essay", "paragraph", "grammar", "style"],
        }

        # Score each configured domain by keyword hits.
        for domain, words in kw.items():
            if domain in scores:
                scores[domain] += float(_count_hits(q, words))

        # Slight boosts based on signal types
        if any(ch.isdigit() for ch in q) and "math" in scores:
            scores["math"] += 0.5
        if any(tok in q for tok in ["=", "->", "::", "{", "}"]) and "coding" in scores:
            scores["coding"] += 0.5

        # If nothing hit, keep intentionally uncertain (forces clarify/reject)
        if max(scores.values() or [0.0]) <= 0.0:
            base = {d: 0.0 for d in self.domains}
            if "general" in base:
                base["general"] = 0.49
            if "writing" in base:
                base["writing"] = 0.26
            if "planning" in base:
                base["planning"] = 0.25
            probs = _normalize(base)
        else:
            # Convert scores to probabilities with mild sharpening.
            probs = {d: (scores[d] ** 1.4) + 0.01 for d in self.domains}
            # Keep a small science backstop for physical sciences
            if "science" in probs and any(scores.get(x, 0.0) > 0 for x in ["physics", "chemistry", "biology"]):
                probs["science"] += 0.25
            probs = _normalize(probs)

        sorted_items = sorted(probs.items(), key=lambda kv: kv[1], reverse=True)
        (top_domain, top_p), (runner_up_domain, runner_up_p) = sorted_items[:2]
        return RouteResult(
            probs=probs,
            top_domain=top_domain,
            top_p=float(top_p),
            runner_up_domain=runner_up_domain,
            runner_up_p=float(runner_up_p),
        )
