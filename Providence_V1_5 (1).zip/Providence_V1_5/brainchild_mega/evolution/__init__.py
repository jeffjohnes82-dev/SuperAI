"""Evolution Core (premium): population-based online tuner.

Maintains a small population of "genomes" (parameter sets) and evolves them
based on observed reward.

This is intentionally lightweight and bounded.
"""
