from __future__ import annotations

import random
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


@dataclass
class Genome:
    """A small set of runtime knobs."""

    reject_threshold: float
    top_k: int
    verification_strictness: float
    budget_scale: float
    confidence_cap: float
    fitness_ema: float = 0.0
    uses: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "reject_threshold": self.reject_threshold,
            "top_k": self.top_k,
            "verification_strictness": self.verification_strictness,
            "budget_scale": self.budget_scale,
            "confidence_cap": self.confidence_cap,
            "fitness_ema": self.fitness_ema,
            "uses": self.uses,
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "Genome":
        return Genome(
            reject_threshold=float(d.get("reject_threshold", 0.5)),
            top_k=int(d.get("top_k", 3)),
            verification_strictness=float(d.get("verification_strictness", 0.5)),
            budget_scale=float(d.get("budget_scale", 1.0)),
            confidence_cap=float(d.get("confidence_cap", 0.95)),
            fitness_ema=float(d.get("fitness_ema", 0.0)),
            uses=int(d.get("uses", 0)),
        )


class EvolutionCore:
    """Population-based tuner.

    - Select a genome for each run (epsilon-greedy on fitness)
    - Update its fitness with reward EMA
    - Periodically mutate non-elite genomes from elites
    """

    def __init__(self, cfg: Dict[str, Any], state: Dict[str, Any]):
        self.cfg = cfg or {}
        self.state = state
        self.rng = random.Random(int(self.cfg.get("seed", 1337)))

        evo_state = self.state.setdefault("evolution", {})
        self.enabled = bool(self.cfg.get("enabled", True))
        self.pop_size = int(self.cfg.get("population", 8))
        self.elite_frac = float(self.cfg.get("elite_fraction", 0.25))
        self.mutate_sigma = float(self.cfg.get("mutate_sigma", 0.05))
        self.eps = float(self.cfg.get("epsilon", 0.15))
        self.update_alpha = float(self.cfg.get("fitness_alpha", 0.15))
        self.evolve_every = int(self.cfg.get("evolve_every", 20))

        if "population" not in evo_state:
            evo_state["population"] = [g.to_dict() for g in self._init_population()]
            evo_state["t"] = 0
            evo_state["active_idx"] = 0
            evo_state["last_evolve_ts"] = time.time()

    def _init_population(self) -> List[Genome]:
        # Initialize around reasonable defaults
        pop: List[Genome] = []
        for i in range(self.pop_size):
            pop.append(
                Genome(
                    reject_threshold=_clamp(0.50 + self.rng.uniform(-0.10, 0.10), 0.10, 0.80),
                    top_k=int(_clamp(3 + self.rng.choice([-1, 0, 1]), 1, 5)),
                    verification_strictness=_clamp(0.50 + self.rng.uniform(-0.20, 0.20), 0.10, 0.95),
                    budget_scale=_clamp(1.00 + self.rng.uniform(-0.25, 0.25), 0.50, 2.00),
                    confidence_cap=_clamp(0.95 + self.rng.uniform(-0.10, 0.05), 0.70, 1.00),
                )
            )
        return pop

    def _load_population(self) -> List[Genome]:
        evo_state = self.state.get("evolution", {})
        return [Genome.from_dict(d) for d in evo_state.get("population", [])]

    def _save_population(self, pop: List[Genome]) -> None:
        self.state.setdefault("evolution", {})["population"] = [g.to_dict() for g in pop]

    def select_genome(self) -> Genome:
        if not self.enabled:
            return self._load_population()[0]

        pop = self._load_population()
        if not pop:
            pop = self._init_population()

        # epsilon-greedy: explore random, else exploit best fitness
        if self.rng.random() < self.eps:
            idx = self.rng.randrange(len(pop))
            mode = "explore"
        else:
            idx = max(range(len(pop)), key=lambda i: pop[i].fitness_ema)
            mode = "exploit"

        evo_state = self.state.setdefault("evolution", {})
        evo_state["active_idx"] = int(idx)
        evo_state["active_mode"] = mode
        evo_state["t"] = int(evo_state.get("t", 0)) + 1
        self._save_population(pop)
        return pop[idx]

    def get_active_genome(self) -> Optional[Genome]:
        pop = self._load_population()
        if not pop:
            return None
        idx = int(self.state.get("evolution", {}).get("active_idx", 0))
        idx = max(0, min(idx, len(pop) - 1))
        return pop[idx]

    def update_active(self, reward: float) -> None:
        if not self.enabled:
            return
        pop = self._load_population()
        if not pop:
            return
        evo_state = self.state.get("evolution", {})
        idx = int(evo_state.get("active_idx", 0))
        idx = max(0, min(idx, len(pop) - 1))

        g = pop[idx]
        g.uses += 1
        g.fitness_ema = (1 - self.update_alpha) * float(g.fitness_ema) + self.update_alpha * float(reward)
        pop[idx] = g
        self._save_population(pop)

        # Maybe evolve
        t = int(evo_state.get("t", 0))
        if t % self.evolve_every == 0:
            self.evolve()

    def evolve(self) -> None:
        pop = self._load_population()
        if not pop:
            return
        n = len(pop)
        elite_n = max(1, int(round(n * self.elite_frac)))
        ranked = sorted(pop, key=lambda g: g.fitness_ema, reverse=True)
        elites = ranked[:elite_n]
        non_elites = ranked[elite_n:]

        # Mutate non-elites from random elites
        new_non: List[Genome] = []
        for g in non_elites:
            parent = self.rng.choice(elites)
            child = Genome(
                reject_threshold=_clamp(parent.reject_threshold + self.rng.gauss(0, self.mutate_sigma), 0.10, 0.80),
                top_k=int(_clamp(parent.top_k + self.rng.choice([-1, 0, 1]), 1, 5)),
                verification_strictness=_clamp(parent.verification_strictness + self.rng.gauss(0, self.mutate_sigma * 2), 0.10, 0.95),
                budget_scale=_clamp(parent.budget_scale + self.rng.gauss(0, self.mutate_sigma * 3), 0.50, 2.00),
                confidence_cap=_clamp(parent.confidence_cap + self.rng.gauss(0, self.mutate_sigma * 2), 0.70, 1.00),
                fitness_ema=0.0,
                uses=0,
            )
            new_non.append(child)

        new_pop = elites + new_non
        # Keep size
        new_pop = new_pop[:n]
        self._save_population(new_pop)
        self.state.setdefault("evolution", {})["last_evolve_ts"] = time.time()
