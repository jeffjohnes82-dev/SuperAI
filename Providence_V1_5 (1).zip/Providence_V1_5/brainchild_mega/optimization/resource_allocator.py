from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict


@dataclass
class ResourceAdjustments:
    budget_scale: float
    lambda_cost: float
    lambda_latency: float
    lambda_halluc: float


def update_resource_allocation(
    state: Dict[str, Any],
    cost_obs: float,
    latency_obs: float,
    halluc_obs: float,
    cost_target: float = 4500.0,
    latency_target: float = 4.0,
    halluc_target: float = 0.03,
    step: float = 0.05,
) -> ResourceAdjustments:
    """Self-evolving resource allocator (Lagrangian/dual updates).

    Interprets cost/latency/hallucination as constraints.
    Increases multipliers when constraints are violated, which pushes budget_scale down.
    """
    opt = state.setdefault("optimization", {})
    lam_c = float(opt.get("lambda_cost", 0.0))
    lam_l = float(opt.get("lambda_latency", 0.0))
    lam_h = float(opt.get("lambda_halluc", 0.0))
    scale = float(opt.get("budget_scale", 1.0))

    # Normalize violations
    v_cost = (float(cost_obs) - float(cost_target)) / max(1.0, float(cost_target))
    v_lat = (float(latency_obs) - float(latency_target)) / max(1.0, float(latency_target))
    v_hal = (float(halluc_obs) - float(halluc_target)) / max(1e-6, float(halluc_target))

    lam_c = max(0.0, lam_c + step * v_cost)
    lam_l = max(0.0, lam_l + step * v_lat)
    lam_h = max(0.0, lam_h + step * v_hal)

    # Budget scale reacts to weighted sum of constraint pressure.
    pressure = 0.7 * lam_h + 0.2 * lam_c + 0.1 * lam_l
    scale = 1.0 / (1.0 + pressure)
    scale = min(1.25, max(0.35, scale))

    opt["lambda_cost"] = lam_c
    opt["lambda_latency"] = lam_l
    opt["lambda_halluc"] = lam_h
    opt["budget_scale"] = scale

    return ResourceAdjustments(budget_scale=scale, lambda_cost=lam_c, lambda_latency=lam_l, lambda_halluc=lam_h)


def scaled_budget(base_budget: int, budget_scale: float) -> int:
    return max(1, int(round(int(base_budget) * float(budget_scale))))
