from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from brainchild_mega.accuracy.hallucination_controller import update_hallucination_controls
from brainchild_mega.decision.tree_game import choose_leaf, update_reward
from brainchild_mega.optimization.resource_allocator import scaled_budget, update_resource_allocation
from brainchild_mega.progress.progress_controller import update_progress_controls
from brainchild_mega.scholastic.competency_tracker import map_leaf_to_subject, update_subject_elo
from brainchild_mega.state.store import StateStore
from brainchild_mega.evolution.evolution_core import EvolutionCore


@dataclass
class RuntimeOverrides:
    reject_threshold: Optional[float] = None
    top_k: Optional[int] = None
    confidence_cap: Optional[float] = None
    budget_scale: Optional[float] = None
    verification_strictness: Optional[float] = None


class MegaSystem:
    """Brainchild Mega: self-evolving control layer.

    It does NOT answer questions itself.
    It updates routing/traversal, verification strictness, and resource budgets
    using simple online learning signals from each run.
    """

    def __init__(self, cfg: Dict[str, Any]):
        mega_cfg = cfg.get("brainchild_mega", {})
        self.enabled = bool(mega_cfg.get("enabled", False))
        self.cfg = mega_cfg
        state_path = Path(mega_cfg.get("state_path", "brainchild_mega/state/mega_state.json"))
        self.store = StateStore(state_path)
        self.state = self.store.load()

        # Evolution Core (premium): optional population-based tuner
        evo_cfg = (mega_cfg.get("evolution") or {})
        self.evo = EvolutionCore(evo_cfg, self.state) if bool(evo_cfg.get("enabled", False)) else None

    def start_run(self) -> None:
        """Select an active evolution genome for this request.

        Ensures evolutionary overrides are stable per user query.
        """
        if not self.enabled:
            return
        if self.evo is None:
            return
        g = self.evo.select_genome()
        # Apply selected genome knobs into state for downstream use (clamped inside EvolutionCore).
        self.state.setdefault("accuracy", {})["verification_strictness"] = float(g.verification_strictness)
        self.state.setdefault("accuracy", {})["confidence_cap"] = float(g.confidence_cap)
        self.state.setdefault("optimization", {})["budget_scale"] = float(g.budget_scale)


# ---------- Decision / traversal ----------
    def choose_leaf(self, leaf_priors: Dict[str, float], taxonomy: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
        algo = self.cfg.get("decision", {}).get("algorithm", "ucb1")
        c = float(self.cfg.get("decision", {}).get("exploration_c", 1.2))
        choice = choose_leaf(leaf_priors, taxonomy=taxonomy, state=self.state, algorithm=algo, exploration_c=c)
        meta = {"path": choice.path, "mode": choice.mode}
        return choice.leaf_id, meta

    # ---------- Online control / overrides ----------
    def compute_overrides(self, base_reject_threshold: float, base_top_k: int) -> RuntimeOverrides:
        if not self.enabled:
            return RuntimeOverrides()

        # Compute simple overrides from current EMAs (do not update state here).
        prog_cfg = self.cfg.get("progress", {})
        target_success = float(prog_cfg.get("target_success", 0.80))
        max_reject = float(prog_cfg.get("max_reject", 0.25))
        succ_ema = float(self.state.get("progress", {}).get("task_success_rate_ema", 0.0))
        rej_ema = float(self.state.get("progress", {}).get("reject_rate_ema", 0.0))

        reject = float(base_reject_threshold)
        top_k = int(base_top_k)

        # If success drops, encourage more compute and fewer abstentions.
        if succ_ema < target_success:
            if rej_ema > max_reject:
                reject = reject - min(0.10, 0.20 * (target_success - succ_ema))
            top_k = min(5, top_k + 1)
        reject = min(0.80, max(0.10, reject))

        top_k = min(5, max(1, top_k))

        cap = float(self.state.get("accuracy", {}).get("confidence_cap", 0.95))
        scale = float(self.state.get("optimization", {}).get("budget_scale", 1.0))
        strict = float(self.state.get("accuracy", {}).get("verification_strictness", 0.50))

        # Evolution core can directly set knobs (bounded).
        if self.evo is not None:
            g = self.evo.get_active_genome()
            if g is not None:
                reject = float(g.reject_threshold)
                top_k = int(g.top_k)
                cap = float(g.confidence_cap)
                scale = float(g.budget_scale)
                strict = float(g.verification_strictness)

        return RuntimeOverrides(reject_threshold=reject, top_k=top_k, confidence_cap=cap, budget_scale=scale, verification_strictness=strict)

    # ---------- Learning update ----------
    def update_from_run(
        self,
        leaf_id: str,
        final_output: Dict[str, Any],
        was_reject: bool,
        cost_tokens: float,
        latency_seconds: float,
        hallucination_estimate: float,
        verified_estimate: float,
    ) -> None:
        if not self.enabled:
            return

        # Update progress stats (success/reject EMAs)
        prog_cfg = self.cfg.get("progress", {})
        target_success = float(prog_cfg.get("target_success", 0.80))
        max_reject = float(prog_cfg.get("max_reject", 0.25))
        update_progress_controls(
            self.state,
            task_success_obs=0.0 if was_reject else 1.0,
            reject_obs=1.0 if was_reject else 0.0,
            target_success=target_success,
            max_reject=max_reject,
        )

        # Update hallucination controller
        hallu_target = float(self.cfg.get("accuracy", {}).get("halluc_target", 0.01))
        update_hallucination_controls(self.state, hallucination_rate_obs=float(hallucination_estimate), target=hallu_target)

        # Update resource allocator
        opt_cfg = self.cfg.get("optimization", {})
        cost_target = float(opt_cfg.get("cost_target", 4500))
        latency_target = float(opt_cfg.get("latency_target", 4.0))
        halluc_target = float(opt_cfg.get("halluc_target", 0.03))
        update_resource_allocation(
            self.state,
            cost_obs=float(cost_tokens),
            latency_obs=float(latency_seconds),
            halluc_obs=float(hallucination_estimate),
            cost_target=cost_target,
            latency_target=latency_target,
            halluc_target=halluc_target,
        )

        # Update scholastic trackers (math/physics/ai focus)
        subj = map_leaf_to_subject(leaf_id)
        if subj:
            update_subject_elo(self.state, subj, outcome=float(verified_estimate))

        # Compute reward for decision policy
        w = self.cfg.get("reward", {})
        w_prog = float(w.get("progress", 0.58))
        w_acc = float(w.get("accuracy", 0.42))
        penalty_h = float(w.get("halluc_penalty", 1.0))
        penalty_cost = float(w.get("cost_penalty", 0.05))
        penalty_lat = float(w.get("latency_penalty", 0.10))

        progress_obs = 0.0 if was_reject else 1.0
        accuracy_obs = float(verified_estimate)

        reward = (w_prog * progress_obs + w_acc * accuracy_obs) - (penalty_h * float(hallucination_estimate))
        reward -= penalty_cost * (float(cost_tokens) / max(1.0, float(self.cfg.get("optimization", {}).get("cost_target", 4500))))
        reward -= penalty_lat * (float(latency_seconds) / max(0.5, float(self.cfg.get("optimization", {}).get("latency_target", 4.0))))

        update_reward(self.state, leaf_id=leaf_id, reward=reward)

        # Evolution update (if enabled)
        if self.evo is not None:
            self.evo.update_active(reward=float(reward))

        # Persist
        self.state.setdefault("meta", {})["last_update_ts"] = time.time()
        self.store.save(self.state)


def estimate_hallucination(final_output: Dict[str, Any]) -> float:
    """Hallucination proxy driven by verification results.

    If verification results exist, we treat high-confidence failures and missing
    required evidence as hallucination events.
    """
    verifs = list(final_output.get("verifications") or [])
    if verifs:
        fails = sum(1 for v in verifs if v.get("status") == "fail")
        conf = float(final_output.get("confidence", 0.0))
        if fails == 0:
            return 0.0
        if conf >= 0.8:
            return min(0.35, 0.08 * fails)
        return min(0.20, 0.05 * fails)

    # Fallback: wording-based heuristic
    text = (final_output.get("details") or final_output.get("overlay") or "").lower()
    if "source" in text or "cite" in text or "http" in text:
        return 0.01
    if any(k in text for k in ["i'm not sure", "uncertain", "may be", "might be"]):
        return 0.02
    if any(k in text for k in ["definitely", "always", "never", "proves", "guaranteed"]):
        return 0.06
    return 0.03


def estimate_verified(final_output: Dict[str, Any]) -> float:
    """Verified proxy.

    Prefer explicit verified_score from verification gate, then boolean verified,
    else fall back to confidence.
    """
    if final_output.get("verified_score") is not None:
        try:
            return float(final_output.get("verified_score"))
        except Exception:
            pass
    if final_output.get("verified") is True:
        return 1.0
    return float(final_output.get("confidence", 0.0))
