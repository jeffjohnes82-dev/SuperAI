from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class ScholasticSnapshot:
    subject: str
    elo: float
    n: int


def update_subject_elo(
    state: Dict[str, Any],
    subject: str,
    outcome: float,
    k: float = 24.0,
) -> ScholasticSnapshot:
    """Self-evolving scholastic tracker.

    outcome: 0..1 where 1=fully correct, 0=wrong.

    This is not about "memorizing facts". It's a lightweight skill-meter
    to detect weak spots and trigger extra verification or deeper compute.
    """
    subjects = state.setdefault("scholastic", {}).setdefault("subjects", {})
    cur = subjects.get(subject, {"elo": 1000.0, "n": 0})
    elo = float(cur.get("elo", 1000.0))
    n = int(cur.get("n", 0))

    # Treat the task difficulty as 1000 by default; later you can set per-leaf difficulty.
    opp = 1000.0
    expected = 1.0 / (1.0 + 10 ** ((opp - elo) / 400.0))
    elo = elo + k * (float(outcome) - expected)
    n += 1

    subjects[subject] = {"elo": elo, "n": n}
    return ScholasticSnapshot(subject=subject, elo=elo, n=n)


def map_leaf_to_subject(leaf_id: str) -> Optional[str]:
    lid = (leaf_id or "").lower()
    if "math" in lid or "statistics" in lid or "logic" in lid:
        return "math"
    if "physics" in lid:
        return "physics"
    if "ai" in lid or "ml" in lid or "machine" in lid:
        return "ai"
    return None
