from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class Edge:
    """Directed edge parent -> child."""

    parent_id: str
    child_id: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Node:
    """Tree node.

    This matches the terminology you specified:
    - root node (id='root')
    - node (any Node)
    - edge (Edge)
    - parent node / child node (via parent_id + children)
    - leaf node (is_leaf=True)
    """

    node_id: str
    parent_id: Optional[str] = None
    children: List[str] = field(default_factory=list)
    is_leaf: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


def build_tree_from_taxonomy(taxonomy: Dict[str, Any]) -> Tuple[Dict[str, Node], List[Edge]]:
    """Build a root->branch->leaf tree from the YAML taxonomy."""
    nodes: Dict[str, Node] = {}
    edges: List[Edge] = []

    nodes["root"] = Node(node_id="root", parent_id=None, children=[], is_leaf=False)

    branches = taxonomy.get("branches", {}) if isinstance(taxonomy, dict) else {}
    for branch_name, branch in branches.items():
        b_id = str(branch_name)
        nodes[b_id] = Node(node_id=b_id, parent_id="root", children=[], is_leaf=False, metadata={"type": "branch"})
        nodes["root"].children.append(b_id)
        edges.append(Edge(parent_id="root", child_id=b_id, metadata={"type": "root->branch"}))

        leaves = (branch or {}).get("leaves", {})
        if isinstance(leaves, dict):
            for leaf_id in leaves.keys():
                l_id = str(leaf_id)
                if l_id not in nodes:
                    nodes[l_id] = Node(node_id=l_id, parent_id=b_id, children=[], is_leaf=True, metadata={"type": "leaf"})
                nodes[b_id].children.append(l_id)
                edges.append(Edge(parent_id=b_id, child_id=l_id, metadata={"type": "branch->leaf"}))

    return nodes, edges
