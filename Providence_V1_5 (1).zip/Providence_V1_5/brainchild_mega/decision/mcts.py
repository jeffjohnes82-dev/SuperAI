from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Any, Dict, Tuple

from brainchild_mega.decision.tree_struct import build_tree_from_taxonomy


@dataclass
class EdgeStats:
    n: int = 0
    reward_sum: float = 0.0

    @property
    def mean(self) -> float:
        return self.reward_sum / self.n if self.n else 0.0


def _edge_key(parent_id: str, child_id: str) -> str:
    return f"{parent_id}->{child_id}"


def _ensure_edge_stats(state: Dict[str, Any]) -> Dict[str, EdgeStats]:
    raw = state.setdefault("decision", {}).setdefault("edge_stats", {})
    out: Dict[str, EdgeStats] = {}
    for k, v in raw.items():
        try:
            out[str(k)] = EdgeStats(n=int(v.get("n", 0)), reward_sum=float(v.get("reward_sum", 0.0)))
        except Exception:
            out[str(k)] = EdgeStats()
    return out


def _write_back_edge_stats(state: Dict[str, Any], stats: Dict[str, EdgeStats]) -> None:
    raw = state.setdefault("decision", {}).setdefault("edge_stats", {})
    for k, s in stats.items():
        raw[k] = {"n": s.n, "reward_sum": s.reward_sum}


def _uct_score(mean: float, parent_n: int, child_n: int, c: float) -> float:
    if child_n == 0:
        return float("inf")
    return mean + c * math.sqrt(math.log(max(1, parent_n)) / child_n)


def choose_leaf_mcts(
    priors: Dict[str, float],
    taxonomy: Dict[str, Any],
    state: Dict[str, Any],
    simulations: int = 32,
    c: float = 1.2,
    prior_weight: float = 0.25,
) -> Tuple[str, Dict[str, Any]]:
    """Tiny MCTS for root->branch->leaf trees.

    Rewards are derived from observed online reward history in `state`.
    If no history exists, priors act as a rollout value.
    """
    nodes, _ = build_tree_from_taxonomy(taxonomy)
    edge_stats = _ensure_edge_stats(state)

    # Precompute branch children lists that exist in priors
    root_children = [c for c in nodes.get("root", nodes["root"]).children if c in nodes]

    def children(nid: str):
        return [c for c in nodes[nid].children if c in nodes]

    def edge_stat(pid: str, cid: str) -> EdgeStats:
        k = _edge_key(pid, cid)
        if k not in edge_stats:
            edge_stats[k] = EdgeStats()
        return edge_stats[k]

    def visit_count(pid: str, cid: str) -> int:
        return edge_stat(pid, cid).n

    def select_child(pid: str, kids: list[str]) -> str:
        # Parent visit count is sum of outgoing edge visits
        parent_n = sum(visit_count(pid, k) for k in kids) + 1
        best = None
        best_score = -1e18
        for k in kids:
            s = edge_stat(pid, k)
            score = _uct_score(s.mean, parent_n, s.n, c=c)
            # Add weak prior for leaves
            if nodes[k].is_leaf:
                score += prior_weight * float(priors.get(k, 0.0))
            if score > best_score:
                best_score = score
                best = k
        return best or random.choice(kids)

    def rollout(leaf_id: str) -> float:
        # Use prior as default rollout reward if we have no empirical reward on leaf edge.
        return float(priors.get(leaf_id, 0.0))

    for _ in range(int(simulations)):
        # Selection: root -> branch
        if not root_children:
            break
        b = select_child("root", root_children)
        # Selection: branch -> leaf
        leaf_candidates = [l for l in children(b) if l in priors]
        if not leaf_candidates:
            # If taxonomy leaf list doesn't overlap priors, fall back to best prior directly.
            break
        l = select_child(b, leaf_candidates)

        r = rollout(l)

        # Backprop
        for pid, cid in [("root", b), (b, l)]:
            st = edge_stat(pid, cid)
            st.n += 1
            st.reward_sum += r

    # Choose leaf with max visits from best branch
    # If no stats, just pick max prior
    best_leaf = None
    best_n = -1
    best_path = ["root"]
    for b in root_children:
        leaf_candidates = [l for l in children(b) if l in priors]
        for l in leaf_candidates:
            n = visit_count(b, l)
            if n > best_n:
                best_n = n
                best_leaf = l
                best_path = ["root", b, l]

    if not best_leaf:
        best_leaf = max(priors.items(), key=lambda kv: kv[1])[0]
        best_path = ["root", best_leaf]

    _write_back_edge_stats(state, edge_stats)
    return best_leaf, {"path": best_path, "mode": "mcts", "simulations": int(simulations)}
