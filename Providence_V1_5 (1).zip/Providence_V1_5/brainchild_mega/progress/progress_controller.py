from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict


@dataclass
class ProgressAdjustments:
    reject_threshold_delta: float
    top_k_delta: int


def _ema(old: float, new: float, alpha: float) -> float:
    return (1 - alpha) * old + alpha * new


def update_progress_controls(
    state: Dict[str, Any],
    task_success_obs: float,
    reject_obs: float,
    target_success: float = 0.80,
    max_reject: float = 0.25,
    alpha: float = 0.15,
    gain: float = 0.20,
) -> ProgressAdjustments:
    """Self-evolving progress maximizer.

    Adjusts two key knobs:
    - reject threshold (lower -> answer more queries -> higher progress, but can hurt accuracy)
    - top_k (higher -> more multi-brain compute -> can boost quality, costs more)

    Returns deltas; the Master can apply them as runtime overrides.
    """
    prog = state.setdefault("progress", {})

    succ_ema = float(prog.get("task_success_rate_ema", 0.0))
    rej_ema = float(prog.get("reject_rate_ema", 0.0))

    succ_ema = _ema(succ_ema, float(task_success_obs), alpha=alpha)
    rej_ema = _ema(rej_ema, float(reject_obs), alpha=alpha)

    prog["task_success_rate_ema"] = succ_ema
    prog["reject_rate_ema"] = rej_ema

    # If success is low, reduce rejects and/or raise top_k.
    success_error = float(target_success) - succ_ema

    reject_threshold_delta = 0.0
    top_k_delta = 0

    if success_error > 0.02:
        # Encourage answering more queries (lower reject threshold) when rejects are high.
        if rej_ema > max_reject:
            reject_threshold_delta = -gain * success_error
        # Encourage more expert plurality when uncertain.
        top_k_delta = 1

    # If reject rate is too high even with ok success, still relax a bit.
    if rej_ema > max_reject * 1.2:
        reject_threshold_delta = min(reject_threshold_delta, -0.02)

    # Bound outputs
    reject_threshold_delta = max(-0.10, min(0.05, reject_threshold_delta))
    top_k_delta = max(0, min(2, top_k_delta))

    return ProgressAdjustments(reject_threshold_delta=reject_threshold_delta, top_k_delta=top_k_delta)
