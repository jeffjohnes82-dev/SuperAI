from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class AccuracyAdjustments:
    verification_strictness: float
    confidence_cap: float


def _ema(old: float, new: float, alpha: float) -> float:
    return (1 - alpha) * old + alpha * new


def update_hallucination_controls(
    state: Dict[str, Any],
    hallucination_rate_obs: float,
    target: float = 0.01,
    alpha: float = 0.15,
    gain: float = 0.8,
) -> AccuracyAdjustments:
    """Self-evolving hallucination minimizer.

    Uses an EMA of observed hallucination rate and a proportional control update.

    - If hallucination exceeds target, increases verification strictness and lowers confidence cap.
    - If hallucination is below target, relaxes slightly for speed.

    hallucination_rate_obs: 0..1
    target: desired max hallucination for high-confidence ungrounded claims
    """
    acc = state.setdefault("accuracy", {})
    ema = float(acc.get("hallucination_rate_ema", 0.0))
    ema = _ema(ema, float(hallucination_rate_obs), alpha=alpha)
    acc["hallucination_rate_ema"] = ema

    strict = float(acc.get("verification_strictness", 0.5))
    cap = float(acc.get("confidence_cap", 0.95))

    error = ema - float(target)
    strict = min(1.0, max(0.0, strict + gain * error))

    # Confidence cap tightens when hallucination is high; loosens otherwise.
    cap = 0.80 + (1.0 - strict) * 0.20  # strict=1 -> 0.80, strict=0 -> 1.00
    cap = min(1.0, max(0.80, cap))

    acc["verification_strictness"] = strict
    acc["confidence_cap"] = cap

    return AccuracyAdjustments(verification_strictness=strict, confidence_cap=cap)
