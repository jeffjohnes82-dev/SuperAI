from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from providence_core import run_query


APP_ROOT = Path(__file__).resolve().parent
UI_DIR = APP_ROOT / "ui"

app = FastAPI(title="Providence UI")

# Static assets
app.mount("/static", StaticFiles(directory=str(UI_DIR)), name="static")


class ChatRequest(BaseModel):
    session_id: str
    message: str


# In-memory session store (prototype)
_sessions: Dict[str, List[Dict[str, str]]] = {}


@app.get("/")
def index():
    return FileResponse(str(UI_DIR / "index.html"))


@app.post("/api/chat")
def chat(req: ChatRequest):
    sid = req.session_id
    msg = (req.message or "").strip()
    hist = _sessions.get(sid, [])
    hist.append({"role": "user", "content": msg})

    payload = run_query(query=msg, config_path="config/config.yaml", session_id=sid, history=hist)

    assistant_msg = payload.get("final", {}).get("overlay") or payload.get("final", {}).get("answer") or ""
    hist.append({"role": "assistant", "content": assistant_msg})
    _sessions[sid] = hist[-60:]

    debug = {
        "decision": payload.get("decision"),
        "router": payload.get("router"),
        "tree": payload.get("tree"),
        "verification": {
            "claims": payload.get("final", {}).get("claims"),
            "verifications": payload.get("final", {}).get("verifications"),
            "verified_score": payload.get("final", {}).get("verified_score"),
            "hallucination_estimate": payload.get("final", {}).get("hallucination_estimate"),
            "can_finalize": payload.get("final", {}).get("can_finalize"),
        },
        "mega_state": payload.get("mega_state"),
        "raw": payload,
    }

    return {
        "assistant": {
            "message": assistant_msg,
            "details": payload.get("final", {}).get("details"),
            "confidence": payload.get("final", {}).get("confidence"),
            "final": payload.get("final", {}).get("final"),
        },
        "debug": debug,
    }
