from __future__ import annotations

import re
import uuid
from typing import Any, Dict, List, Tuple

from schemas.claims import Claim


_UNIT_RE = re.compile(r"\b(?P<num>[-+]?\d+(?:\.\d+)?)\s*(?P<unit>N|J|W|Pa|kg|m|s|Hz|V|A|C|T|ohm)\b")


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


def extract_claims(
    query: str,
    output_text: str,
    domain: str,
    strictness: float,
) -> List[Dict[str, Any]]:
    """Extract a small set of verifiable claims.

    This is intentionally heuristic in v1; the verification loop becomes powerful
    once your brains natively emit claims.
    """
    claims: List[Claim] = []

    text = output_text

    # Math: find simple "x = 3.14" patterns
    for m in re.finditer(r"\b([A-Za-z]\w*)\s*=\s*([-+]?\d+(?:\.\d+)?)\b", text):
        var, val = m.group(1), m.group(2)
        claims.append(
            Claim(
                id=_new_id("math"),
                type="math",
                text=f"{var} equals {val}",
                value=str(val),
                evidence_required=False,
            )
        )

    # Physics: look for number + unit
    for m in _UNIT_RE.finditer(text):
        num, unit = m.group("num"), m.group("unit")
        claims.append(
            Claim(
                id=_new_id("phys"),
                type="physics",
                text=f"Quantity is {num} {unit}",
                value=str(num),
                units=str(unit),
                evidence_required=False,
            )
        )

    # Facts: if strictness is moderate/high, require evidence for numeric statements that
    # look like factual assertions.
    if strictness >= 0.35:
        has_year = bool(re.search(r"\b(19\d{2}|20\d{2})\b", text))
        has_number = bool(re.search(r"\b\d+(?:\.\d+)?\b", text))
        has_entityish = bool(re.search(r"\b[A-Z][a-z]{2,}\b", text))
        if (has_year or has_number) and has_entityish:
            claims.append(
                Claim(
                    id=_new_id("fact"),
                    type="fact",
                    text="Answer contains specific entity + number/date; evidence required.",
                    evidence_required=True,
                    metadata={"has_year": has_year, "has_number": has_number, "has_entityish": has_entityish},
                )
            )

    # Domain hinting: mark some claims types based on domain
    if domain in {"coding", "software_engineering", "ai"} and "```" in text:
        claims.append(Claim(id=_new_id("code"), type="code", text="Contains code block", evidence_required=False))

    # Deduplicate to keep list small
    out: List[Dict[str, Any]] = []
    seen: set[Tuple[str, str, str]] = set()
    for c in claims:
        key = (c.type, c.value or "", c.units or "")
        if key in seen:
            continue
        seen.add(key)
        out.append(c.to_dict())
        if len(out) >= 6:
            break
    return out
