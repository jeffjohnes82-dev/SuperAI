from __future__ import annotations

from typing import Any, Dict

from schemas.claims import VerificationResult


VALID_UNITS = {
    "N",
    "J",
    "W",
    "Pa",
    "kg",
    "m",
    "s",
    "Hz",
    "V",
    "A",
    "C",
    "T",
    "ohm",
}


def verify_unit_claim(claim: Dict[str, Any]) -> Dict[str, Any]:
    unit = str(claim.get("units") or "").strip()
    if not unit:
        return VerificationResult(claim_id=claim["id"], status="unknown", reason="no unit").to_dict()
    if unit not in VALID_UNITS:
        return VerificationResult(claim_id=claim["id"], status="unknown", reason=f"unit '{unit}' not recognized").to_dict()
    return VerificationResult(claim_id=claim["id"], status="pass", reason="unit recognized").to_dict()
