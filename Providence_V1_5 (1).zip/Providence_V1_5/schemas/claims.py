from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Dict, Literal, Optional


ClaimType = Literal["math", "physics", "fact", "definition", "recommendation", "code"]
VerifyStatus = Literal["pass", "fail", "unknown"]


@dataclass
class Claim:
    """Atomic claim extracted from an output.

    Keep this deliberately small. Claims are what you verify.
    """

    id: str
    type: ClaimType
    text: str
    value: Optional[str] = None
    units: Optional[str] = None
    evidence_required: bool = False
    metadata: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class VerificationResult:
    claim_id: str
    status: VerifyStatus
    reason: str
    evidence: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
