from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

import yaml


def _flatten_taxonomy(raw: Dict[str, Any]) -> List[str]:
    """Flatten taxonomy into a list of leaf ids (order preserved)."""
    tax = raw.get("taxonomy") or {}
    branches = tax.get("branches") or {}

    ordered: List[str] = []
    for _branch_name, branch in branches.items():
        leaves = (branch.get("leaves") or {}).keys()
        for leaf_id in leaves:
            ordered.append(str(leaf_id))

    # de-duplicate while preserving order
    seen = set()
    flat: List[str] = []
    for leaf_id in ordered:
        if leaf_id not in seen:
            flat.append(leaf_id)
            seen.add(leaf_id)
    return flat


@dataclass(frozen=True)
class Config:
    raw: Dict[str, Any]

    @property
    def routing(self) -> Dict[str, Any]:
        return self.raw.get("routing_policy", {})

    @property
    def taxonomy(self) -> Dict[str, Any]:
        return self.raw.get("taxonomy", {})

    @property
    def focus(self) -> Dict[str, Any]:
        return self.raw.get("focus", {})

    @property
    def domains(self) -> List[str]:
        explicit = list((self.raw.get("brains", {}) or {}).get("domains", []) or [])
        if explicit:
            return explicit
        flat = _flatten_taxonomy(self.raw)
        if flat:
            return flat + ["general"]
        return ["general"]


def load_config(path: str | Path) -> Config:
    p = Path(path)
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    if "routing_policy" not in data:
        raise ValueError("config is missing 'routing_policy'")
    return Config(raw=data)
