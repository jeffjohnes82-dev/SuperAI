from __future__ import annotations

import argparse
from pathlib import Path

from config_loader import load_config
from brains.registry import build_brain_registry
from master.orchestrator import MasterBrain
from master.verification_gate import verify_output
from router.heuristic_router import HeuristicRouter
from brainchild_mega import estimate_hallucination, estimate_verified


def run(query: str, config_path: str) -> int:
    cfg = load_config(config_path)

    router = HeuristicRouter(domains=cfg.domains)
    rr = router.route(query)

    brains = build_brain_registry(cfg.domains)
    master = MasterBrain(cfg.raw, log_dir=Path("logs"))
    decision = master.decide(rr)

    # Budgets are placeholders, but we still run them through the self-evolving allocator.
    total_budget_base = int(cfg.raw.get("budgets", {}).get("token_budget_total", 2400))
    budget_scale = float(master.mega.state.get("optimization", {}).get("budget_scale", 1.0)) if master.mega.enabled else 1.0
    total_budget = max(1, int(round(total_budget_base * budget_scale)))

    # Optionally do sequential leaf execution: stop early when a leaf looks "final".
    seq_stop = bool(cfg.raw.get("brainchild_mega", {}).get("decision", {}).get("sequential_stop", True))
    stop_conf = float(cfg.raw.get("brainchild_mega", {}).get("decision", {}).get("stop_if_confidence_at_least", 0.90))

    # Verification strictness (0..1). When Brainchild Mega is enabled, this self-evolves.
    strict_default = float(cfg.raw.get("verification", {}).get("strictness_default", 0.50))
    strictness = (
        float(master.mega.state.get("accuracy", {}).get("verification_strictness", strict_default))
        if master.mega.enabled
        else strict_default
    )

    executed = []
    outputs = []
    per_brain = max(1, total_budget // max(1, len(decision.chosen_brains)))

    t0 = __import__("time").time()
    for dom in decision.chosen_brains:
        brain = brains.get(dom, brains["general"])
        out = brain.solve(query, context={}, budget=per_brain)

        # Run verification gate; attach claims/verifications to the leaf output.
        vs = verify_output(query=query, domain=dom, output=out, strictness=strictness)
        out["claims"] = vs.claims
        out["verifications"] = vs.verifications
        out["verified_score"] = vs.verified_score
        out["hallucination_estimate"] = vs.hallucination_estimate
        out["can_finalize"] = vs.can_finalize
        out["verification_reason"] = vs.reason
        # A conservative boolean "verified" flag for compatibility.
        out["verified"] = bool(vs.can_finalize and vs.verified_score >= 0.80)

        outputs.append(out)
        executed.append(dom)

        # Stop only if the leaf is "final enough" AND verification gate allows finalization.
        leaf_ready = (out.get("final") is True) or (float(out.get("confidence", 0.0)) >= stop_conf)
        if seq_stop and leaf_ready and bool(out.get("can_finalize", True)):
            break
    latency_seconds = __import__("time").time() - t0

    final = master.merge(decision, outputs, rr)

    # If verification is strict and we still have verification failures, do not present
    # the result as finalized. This reduces "confident wrong" behavior.
    strict_high = float(cfg.raw.get("verification", {}).get("bands", {}).get("high", 0.70))
    if strictness >= strict_high:
        verifs = list(final.get("verifications") or [])
        fails = [v for v in verifs if v.get("status") == "fail"]
        if fails:
            final["final"] = False
            final["confidence"] = min(float(final.get("confidence", rr.top_p)), 0.55)
            final["overlay"] = "Verification failed under strict mode — I need more grounding to answer safely."
            fail_lines = "\n".join(f"- {f.get('reason','fail')} (claim_id={f.get('claim_id')})" for f in fails[:6])
            final["details"] = (final.get("details") or "") + "\n\n[verification strict] blocking failures:\n" + fail_lines

    # Update Brainchild Mega online controllers.
    hallu_est = estimate_hallucination(final)
    verified_est = estimate_verified(final)
    # rough proxy: total_budget acts as "tokens"
    for dom in executed[:1] if executed else []:
        master.mega.update_from_run(
            leaf_id=dom,
            final_output=final,
            was_reject=(decision.mode == "reject"),
            cost_tokens=float(total_budget),
            latency_seconds=float(latency_seconds),
            hallucination_estimate=float(hallu_est),
            verified_estimate=float(verified_est),
        )

    payload = {
        "query": query,
        "router": {
            "top_domain": rr.top_domain,
            "top_p": rr.top_p,
            "runner_up_domain": rr.runner_up_domain,
            "runner_up_p": rr.runner_up_p,
            "probs": rr.probs,
        },
        "decision": {"mode": decision.mode, "chosen": decision.chosen_brains, "executed": executed, "per_brain_budget": per_brain, "meta": decision.meta},
        "runtime": {"budget_scale": budget_scale, "total_budget": total_budget, "latency_seconds": latency_seconds, "verification_strictness": strictness},
        "mega_state": master.mega.state if master.mega.enabled else None,
        "outputs": outputs,
        "final": final,
    }
    master.log_run(payload)

    print("\n=== Router ===")
    print(f"top: {rr.top_domain} ({rr.top_p:.2f}) | runner-up: {rr.runner_up_domain} ({rr.runner_up_p:.2f})")
    print("probs:")
    for k, v in sorted(rr.probs.items(), key=lambda kv: kv[1], reverse=True):
        print(f"  {k:>8}: {v:.2f}")

    print("\n=== Decision ===")
    print(f"mode: {decision.mode}")
    print(f"chosen: {decision.chosen_brains}")

    print("\n=== Output ===")
    print(final.get("overlay", final.get("answer", "")))
    if final.get("details"):
        print("\n--- details ---")
        print(final["details"])

    print("\n(log written to ./logs)\n")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Superbrain mockup CLI")
    parser.add_argument("query", type=str, help="The query to route/answer")
    parser.add_argument("--config", type=str, default="config/config.yaml", help="Path to YAML config")
    args = parser.parse_args()
    return run(args.query, args.config)


if __name__ == "__main__":
    raise SystemExit(main())
