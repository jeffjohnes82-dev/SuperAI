from __future__ import annotations

from importlib import import_module
from typing import Dict, List

from brains.base import Brain, TemplateBrain


def _class_name_from_leaf(leaf_id: str) -> str:
    """Convert leaf id like 'natsci.earth_science' -> 'EarthScienceBrain'."""
    last = leaf_id.split(".")[-1]
    parts = [p for p in last.split("_") if p]
    return "".join(p[:1].upper() + p[1:] for p in parts) + "Brain"


def _fallback(leaf_id: str) -> Brain:
    return TemplateBrain(
        name=leaf_id,
        specialty=f"{leaf_id} (generic specialist)",
        checklist=[
            "Restate the goal and constraints",
            "Choose an approach and outline steps",
            "Execute with checks and summarize",
        ],
    )


def _load_leaf_brain(leaf_id: str) -> Brain:
    if leaf_id == "general":
        return TemplateBrain(
            name="general",
            specialty="general technical assistant",
            checklist=[
                "Clarify goal and constraints",
                "Give a concise answer",
                "Provide actionable next steps",
            ],
        )

    # Expected: <branch>.<leaf>
    if "." not in leaf_id:
        return _fallback(leaf_id)

    branch, leaf = leaf_id.split(".", 1)
    module_path = f"brains.branches.{branch}.{leaf}"
    cls_name = _class_name_from_leaf(leaf_id)

    try:
        mod = import_module(module_path)
        cls = getattr(mod, cls_name, None)
        if cls is None:
            # Fallback: pick first Brain-like class in module
            for attr in dir(mod):
                if attr.endswith("Brain"):
                    cls = getattr(mod, attr)
                    break
        if cls is not None:
            return cls()
    except Exception:
        # Not found or import failed
        return _fallback(leaf_id)

    return _fallback(leaf_id)


def build_brain_registry(domains: List[str]) -> Dict[str, Brain]:
    """Instantiate brains for each configured leaf/domain.

    Leaves can be extended in config without changing code.
    """
    registry: Dict[str, Brain] = {"general": _load_leaf_brain("general")}
    for d in domains:
        if d in registry:
            continue
        registry[d] = _load_leaf_brain(d)
    return registry
