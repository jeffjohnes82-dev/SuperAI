from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

from brains.base import Brain
from brains.expert.solvers import expert_solve


@dataclass
class BackendChoice:
    backend: str  # inhouse|expert|api
    reason: str


class BrainManager:
    """Chooses execution backend per leaf.

    - expert backend is used only if leaf probability >= min_leaf_p
    - api backend is optional and disabled by default
    """

    def __init__(self, cfg: Dict[str, Any]):
        self.cfg = cfg

    def choose_backend(self, leaf_id: str, leaf_p: float) -> BackendChoice:
        rt = self.cfg.get("runtime", {})
        backend = str(rt.get("backend", "inhouse"))

        expert_cfg = rt.get("expert", {}) or {}
        expert_enabled = bool(expert_cfg.get("enabled", False))
        min_p = float(expert_cfg.get("min_leaf_p", 0.90))

        api_cfg = rt.get("api", {}) or {}
        api_enabled = bool(api_cfg.get("enabled", False))

        if backend in {"expert", "hybrid", "api"}:
            # hybrid: prefer expert at high confidence, else API if enabled, else inhouse
            if expert_enabled and leaf_p >= min_p:
                if expert_solve(leaf_id, "") is not None:
                    return BackendChoice("expert", f"leaf_p {leaf_p:.2f} >= {min_p:.2f}")
                # Even if no empty-query hint, attempt solve at runtime.
                return BackendChoice("expert", f"leaf_p {leaf_p:.2f} >= {min_p:.2f}")

            if backend in {"api", "hybrid"} and api_enabled:
                return BackendChoice("api", "api enabled")

        return BackendChoice("inhouse", "default")

    def run_expert(self, leaf_id: str, query: str) -> Optional[Dict[str, Any]]:
        return expert_solve(leaf_id, query)
