from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class ChemistryBrain(TemplateBrain):
    """Chemistry specialist brain."""

    def __init__(self):
        super().__init__(
            name="chemistry",
            specialty="chemistry (reactions, structures, and quantitative stoichiometry)",
            checklist=[
                "Identify the chemistry area (gen chem/organic/biochem/physical)",
                "Write the balanced reaction or structural relationship",
                "Track units (moles, molarity, mass %) and significant figures",
                "Identify limiting reagent / equilibrium / kinetics regime",
                "Explain the underlying mechanism or driving force (electrostatics, bonding, entropy)",
                "Sanity-check with trends (periodic trends, pKa, oxidation state)",
            ],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
