from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class ScienceBrain(TemplateBrain):
    """General science brain (umbrella / fallback).

    Use this for cross-disciplinary questions or when the router isn't
    confident enough to select physics/chemistry/biology.
    """

    def __init__(self):
        super().__init__(
            name="science",
            specialty="cross-disciplinary science",
            checklist=[
                "Restate the question in precise scientific terms",
                "Identify the relevant scale (molecular/cellular/organism/planetary, etc.)",
                "List key variables and assumptions",
                "Explain the core mechanism/model",
                "Give a simple example or intuition",
                "If there are competing models, contrast them",
            ],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        # Use parent formatting.
        return super().solve(query, context, budget)
