from __future__ import annotations

from brains.base import TemplateBrain


class ReinforcementLearningBrain(TemplateBrain):
    """Specialist brain for ai.reinforcement_learning."""

    def __init__(self):
        super().__init__(
            name="ai.reinforcement_learning",
            specialty="reinforcement learning",
            checklist=['Define environment, state, action, reward', 'Pick algorithm family (policy gradient, Q-learning, model-based)', 'Stability tricks (normalization, clipping, entropy)', 'Evaluation: sample efficiency + generalization'],
        )
