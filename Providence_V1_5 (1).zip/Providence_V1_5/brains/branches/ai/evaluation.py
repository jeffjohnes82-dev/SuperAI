from __future__ import annotations

from brains.base import TemplateBrain


class EvaluationBrain(TemplateBrain):
    """Specialist brain for ai.evaluation."""

    def __init__(self):
        super().__init__(
            name="ai.evaluation",
            specialty="AI evaluation & benchmarking",
            checklist=['Define task taxonomy and metrics', 'Build gold/weak labels and test suite', 'Measure calibration and hallucinations', 'Set regression gates and CI hooks'],
        )
