from __future__ import annotations

from brains.base import TemplateBrain


class GeneralBrain(TemplateBrain):
    """Specialist brain for ai.general."""

    def __init__(self):
        super().__init__(
            name="ai.general",
            specialty="AI engineering & reasoning (general)",
            checklist=['Clarify goal, constraints, and success metric', 'Select approach (modeling, search, optimization, verification)', 'Provide implementation outline + evaluation plan', 'List failure modes and safety/robustness checks (technical)'],
        )
