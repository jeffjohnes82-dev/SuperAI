from __future__ import annotations

from typing import Any, Dict, List

from master.types import BrainOutput


def _best_output(outputs: List[Dict[str, Any]]) -> Dict[str, Any] | None:
    if not outputs:
        return None
    return sorted(outputs, key=lambda o: float(o.get("verified_score") or o.get("confidence") or 0.0), reverse=True)[0]


class FinalReasonerBrain:
    """Deterministic synthesis brain.

    This is an in-house final pass that:
    - consolidates multi-leaf answers
    - prefers verified/checked outputs
    - produces a clean final overlay + actionable details

    It does NOT invent citations; it will hedge if evidence-required claims failed.
    """

    name = "ai.final_reasoner"

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        outputs = list(context.get("candidate_outputs") or [])
        router = context.get("router") or {}
        decision = context.get("decision") or {}
        strictness = float(context.get("verification_strictness") or 0.5)

        best = _best_output(outputs)
        # Gather verification summary
        all_verifs: List[Dict[str, Any]] = []
        all_claims: List[Dict[str, Any]] = []
        for o in outputs:
            all_claims.extend(list(o.get("claims") or []))
            all_verifs.extend(list(o.get("verifications") or []))
        fails = [v for v in all_verifs if v.get("status") == "fail"]

        # Compose overlay
        if fails and strictness >= 0.70:
            overlay = "I can’t finalize confidently: verification failed for some claims."
        elif best and (best.get("overlay") or best.get("answer")):
            overlay = str(best.get("overlay") or best.get("answer"))
        else:
            overlay = f"(Synthesized) {query}"

        # Details
        lines: List[str] = []
        lines.append(f"[final_reasoner] mode={decision.get('mode')} top={router.get('top_leaf')}:{float(router.get('top_p',0.0)):.2f}")
        if outputs:
            lines.append("contributors:")
            for o in outputs:
                b = o.get("brain", "?")
                conf = float(o.get("confidence", 0.0))
                vs = o.get("verified_score")
                lines.append(f"- {b}: confidence={conf:.2f} verified_score={vs}")
        if fails:
            lines.append(f"verification_fails={len(fails)} (strictness={strictness:.2f})")
            for v in fails[:5]:
                lines.append(f"- FAIL {v.get('claim_id')}: {v.get('reason')}")
            lines.append("Suggested next step: provide sources/constraints or ask a narrower technical question.")
        else:
            # Try to add a concise synthesis if multiple outputs
            if len(outputs) >= 2:
                lines.append("synthesis:")
                # Take top 2 overlays and combine
                ranked = sorted(outputs, key=lambda o: float(o.get("verified_score") or o.get("confidence") or 0.0), reverse=True)
                for o in ranked[:3]:
                    lines.append(f"- {o.get('brain','?')}: {(o.get('overlay') or o.get('answer') or '').strip()}")
            lines.append("next_steps:")
            lines.append("- If you want implementation, specify constraints (platform, performance, budget).")
            lines.append("- If you want rigor, request verification (derivations, unit checks, tests).")

        confidence = 0.72
        if best:
            confidence = float(best.get("confidence", confidence))
        # In strict mode, lower confidence if any fails
        if fails and strictness >= 0.70:
            confidence = min(confidence, 0.55)

        return {
            "brain": self.name,
            "confidence": confidence,
            "overlay": overlay,
            "details": "\n".join(lines),
            "claims": all_claims,
            "verifications": all_verifs,
            "final": not (fails and strictness >= 0.70),
            "metadata": {"budget": budget, "fails": len(fails)},
        }
