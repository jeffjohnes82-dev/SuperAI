"""AI branch specialist brains (premium).

These are lightweight in-house 'role brains' that provide structured playbooks.
The final_reasoner brain performs deterministic synthesis of prior leaves.
"""
