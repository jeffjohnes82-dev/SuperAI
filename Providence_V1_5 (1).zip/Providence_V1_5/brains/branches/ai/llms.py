from __future__ import annotations

from brains.base import TemplateBrain


class LlmsBrain(TemplateBrain):
    """Specialist brain for ai.llms."""

    def __init__(self):
        super().__init__(
            name="ai.llms",
            specialty="LLMs (prompting, RAG, finetuning, evals)",
            checklist=['Clarify task type (chat, extraction, agent, RAG)', 'Choose architecture: prompt-only vs RAG vs finetune', 'Define eval set + success metrics', 'Design constraints: latency/cost/hallucination', 'Iterate: analyze failures → improve prompts/tools'],
        )
