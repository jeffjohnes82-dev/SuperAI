from __future__ import annotations

from brains.base import TemplateBrain


class MachineLearningBrain(TemplateBrain):
    """Specialist brain for ai.machine_learning."""

    def __init__(self):
        super().__init__(
            name="ai.machine_learning",
            specialty="machine learning (supervised/unsupervised)",
            checklist=['Define data schema + target', 'Select baseline model and metrics', 'Plan train/val/test split + leakage checks', 'Outline feature/architecture choices + tuning', 'Deployment and monitoring plan'],
        )
