from __future__ import annotations

from brains.base import TemplateBrain


class AgentsBrain(TemplateBrain):
    """Specialist brain for ai.agents."""

    def __init__(self):
        super().__init__(
            name="ai.agents",
            specialty="AI agents & planning",
            checklist=['Define tools, permissions, and objective', 'Select planner (react, plan-execute, tree search)', 'Add memory + reflection loop', 'Add guardrails: budget caps, verifier gates'],
        )
