from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class LogicBrain(TemplateBrain):
    """Specialist brain for forsci.logic."""

    def __init__(self):
        super().__init__(
            name="forsci.logic",
            specialty="forsci / logic",
            checklist=['Translate into formal statements', 'Apply inference rules', 'Check validity and counterexamples'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
