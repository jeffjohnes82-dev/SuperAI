from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class StatisticsBrain(TemplateBrain):
    """Specialist brain for forsci.statistics."""

    def __init__(self):
        super().__init__(
            name="forsci.statistics",
            specialty="forsci / statistics",
            checklist=['Define variables and assumptions', 'Pick appropriate model/test', 'Compute/interpret results', 'Note limitations'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
