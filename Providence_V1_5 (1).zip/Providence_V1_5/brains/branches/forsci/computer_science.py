from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class ComputerScienceBrain(TemplateBrain):
    """Specialist brain for forsci.computer_science."""

    def __init__(self):
        super().__init__(
            name="forsci.computer_science",
            specialty="forsci / computer_science",
            checklist=['Identify problem type (algorithms/systems)', 'Choose data structures/approach', 'Analyze complexity', 'Give implementation notes'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
