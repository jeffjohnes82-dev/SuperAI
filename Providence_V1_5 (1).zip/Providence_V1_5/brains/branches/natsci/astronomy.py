from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class AstronomyBrain(TemplateBrain):
    """Specialist brain for natsci.astronomy."""

    def __init__(self):
        super().__init__(
            name="natsci.astronomy",
            specialty="natsci / astronomy",
            checklist=['Clarify scale (stellar/galactic/cosmology)', 'Use relevant physics and observation methods', 'Check units and orders of magnitude'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
