from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class PhysicsBrain(TemplateBrain):
    """Specialist brain for natsci.physics."""

    def __init__(self):
        super().__init__(
            name="natsci.physics",
            specialty="natsci / physics",
            checklist=['Identify relevant laws', 'Define variables/units', 'Write governing equations', 'Check dimensional consistency', 'Compute and interpret result'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
