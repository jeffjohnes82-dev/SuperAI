from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class EarthScienceBrain(TemplateBrain):
    """Specialist brain for natsci.earth_science."""

    def __init__(self):
        super().__init__(
            name="natsci.earth_science",
            specialty="natsci / earth_science",
            checklist=['Identify domain (geology/meteorology/ocean)', 'State key processes and timescales', 'Use data/measurements where relevant'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
