from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class EcologyBrain(TemplateBrain):
    """Specialist brain for natsci.ecology."""

    def __init__(self):
        super().__init__(
            name="natsci.ecology",
            specialty="natsci / ecology",
            checklist=['Clarify system and assumptions', 'Use scientific method: model → prediction → check', 'Provide mechanism + next steps'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
