from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class CivilBrain(TemplateBrain):
    """Specialist brain for techeng.civil."""

    def __init__(self):
        super().__init__(
            name="techeng.civil",
            specialty="techeng / civil",
            checklist=['Define geometry/loads/supports', 'Compute stresses/deflections', 'Check safety factors/codes (if provided)'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
