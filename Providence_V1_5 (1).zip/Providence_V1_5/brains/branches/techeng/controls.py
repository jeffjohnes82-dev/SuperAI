from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class ControlsBrain(TemplateBrain):
    """Specialist brain for techeng.controls."""

    def __init__(self):
        super().__init__(
            name="techeng.controls",
            specialty="techeng / controls",
            checklist=['Clarify requirements', 'Design solution', 'Consider constraints (cost/latency/safety)', 'Test and iterate'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
