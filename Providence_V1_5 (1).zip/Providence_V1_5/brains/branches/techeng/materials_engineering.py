from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class MaterialsEngineeringBrain(TemplateBrain):
    """Specialist brain for techeng.materials_engineering."""

    def __init__(self):
        super().__init__(
            name="techeng.materials_engineering",
            specialty="techeng / materials_engineering",
            checklist=['Clarify requirements', 'Design solution', 'Consider constraints (cost/latency/safety)', 'Test and iterate'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
