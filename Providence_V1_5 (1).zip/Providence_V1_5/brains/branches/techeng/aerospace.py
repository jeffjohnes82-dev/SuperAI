from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class AerospaceBrain(TemplateBrain):
    """Specialist brain for techeng.aerospace."""

    def __init__(self):
        super().__init__(
            name="techeng.aerospace",
            specialty="techeng / aerospace",
            checklist=['Clarify regime (aero/orbit)', 'Apply governing equations', 'Check feasibility and units'],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
