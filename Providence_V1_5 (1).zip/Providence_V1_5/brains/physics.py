from __future__ import annotations

from typing import Any, Dict

from brains.base import TemplateBrain
from master.types import BrainOutput


class PhysicsBrain(TemplateBrain):
    """Physics specialist brain."""

    def __init__(self):
        super().__init__(
            name="physics",
            specialty="physics (models, laws, and quantitative reasoning)",
            checklist=[
                "Identify the relevant branch (mechanics/EM/thermo/quantum/relativity)",
                "Write down the governing principles/laws",
                "Define symbols, units, and coordinate system",
                "Check limiting cases and dimensional consistency",
                "If a calculation is needed, set up equations before plugging numbers",
                "State the result with units and interpretation",
            ],
        )

    def solve(self, query: str, context: Dict[str, Any], budget: int) -> BrainOutput:
        return super().solve(query, context, budget)
