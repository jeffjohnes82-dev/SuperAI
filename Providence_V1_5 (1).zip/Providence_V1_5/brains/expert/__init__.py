"""In-house expert solvers.

These are small deterministic solvers used only when router confidence is high
(>= configured threshold).
"""
