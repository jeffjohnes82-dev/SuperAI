from __future__ import annotations

import math
import re
from typing import Any, Dict, Optional, Tuple


def _num(x: str) -> Optional[float]:
    try:
        return float(x)
    except Exception:
        return None


# --- Physics expert: F=ma, kinematics v=u+at, s=vt ---
_RE_M = re.compile(r"\bm\s*=\s*([-+]?\d+(?:\.\d+)?)\b")
_RE_A = re.compile(r"\ba\s*=\s*([-+]?\d+(?:\.\d+)?)\b")
_RE_U = re.compile(r"\bu\s*=\s*([-+]?\d+(?:\.\d+)?)\b")
_RE_V = re.compile(r"\bv\s*=\s*([-+]?\d+(?:\.\d+)?)\b")
_RE_T = re.compile(r"\bt\s*=\s*([-+]?\d+(?:\.\d+)?)\b")
_RE_S = re.compile(r"\bs\s*=\s*([-+]?\d+(?:\.\d+)?)\b")


def solve_physics(query: str) -> Optional[Dict[str, Any]]:
    q = query.lower()
    m = _RE_M.search(q)
    a = _RE_A.search(q)
    if ("f=" in q or "force" in q) and m and a:
        mv, av = _num(m.group(1)), _num(a.group(1))
        if mv is not None and av is not None:
            F = mv * av
            return {
                "overlay": f"Force F = m·a = {F:.6g} N",
                "details": f"Using F=m·a with m={mv} kg and a={av} m/s^2 ⇒ F={F} N.",
                "confidence": 0.97,
                "final": True,
                "claims": [{"id":"phys_F","type":"physics","text":"Force is computed as m*a","value":str(F),"units":"N","evidence_required":False}],
            }

    # v = u + a t
    u = _RE_U.search(q)
    v = _RE_V.search(q)
    t = _RE_T.search(q)
    if ("v=" in q or "velocity" in q) and u and a and t:
        uv, av, tv = _num(u.group(1)), _num(a.group(1)), _num(t.group(1))
        if uv is not None and av is not None and tv is not None:
            V = uv + av * tv
            return {
                "overlay": f"v = u + a·t = {V:.6g} m/s",
                "details": f"Using v=u+a·t with u={uv}, a={av}, t={tv} ⇒ v={V} m/s.",
                "confidence": 0.96,
                "final": True,
                "claims": [{"id":"phys_v","type":"physics","text":"v computed as u+a*t","value":str(V),"units":"m","evidence_required":False}],
            }

    # s = v t
    if ("distance" in q or "displacement" in q or "s=" in q) and v and t:
        vv, tv = _num(v.group(1)), _num(t.group(1))
        if vv is not None and tv is not None:
            S = vv * tv
            return {
                "overlay": f"s = v·t = {S:.6g} m",
                "details": f"Using s=v·t with v={vv} and t={tv} ⇒ s={S} m.",
                "confidence": 0.95,
                "final": True,
                "claims": [{"id":"phys_s","type":"physics","text":"s computed as v*t","value":str(S),"units":"m","evidence_required":False}],
            }

    return None


# --- Chemistry expert: molar mass ---
_ATOMIC = {
    "H": 1.008,
    "C": 12.011,
    "N": 14.007,
    "O": 15.999,
    "Na": 22.990,
    "Cl": 35.45,
    "K": 39.098,
    "S": 32.06,
    "P": 30.974,
    "Ca": 40.078,
    "Mg": 24.305,
    "Fe": 55.845,
}


def _parse_formula(formula: str) -> Optional[Dict[str, int]]:
    # Basic parser: elements with optional counts, supports parentheses one level
    tokens = re.findall(r"[A-Z][a-z]?|\d+|\(|\)", formula)
    if not tokens:
        return None

    stack = [dict()]
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        if tok == "(":
            stack.append(dict())
            i += 1
        elif tok == ")":
            if len(stack) == 1:
                return None
            group = stack.pop()
            i += 1
            mult = 1
            if i < len(tokens) and tokens[i].isdigit():
                mult = int(tokens[i]); i += 1
            for el, cnt in group.items():
                stack[-1][el] = stack[-1].get(el, 0) + cnt * mult
        elif re.fullmatch(r"[A-Z][a-z]?", tok):
            el = tok
            i += 1
            cnt = 1
            if i < len(tokens) and tokens[i].isdigit():
                cnt = int(tokens[i]); i += 1
            stack[-1][el] = stack[-1].get(el, 0) + cnt
        else:
            # stray number
            return None

    if len(stack) != 1:
        return None
    return stack[0]


def molar_mass(formula: str) -> Optional[float]:
    comp = _parse_formula(formula)
    if not comp:
        return None
    mass = 0.0
    for el, cnt in comp.items():
        if el not in _ATOMIC:
            return None
        mass += _ATOMIC[el] * cnt
    return mass


def solve_chemistry(query: str) -> Optional[Dict[str, Any]]:
    m = re.search(r"\b([A-Z][A-Za-z0-9\(\)]{0,30})\b", query)
    if not m:
        return None
    formula = m.group(1)
    if len(formula) < 2:
        return None
    if any(k in query.lower() for k in ["molar mass", "molecular weight", "molar mass of"]):
        mm = molar_mass(formula)
        if mm is None:
            return None
        return {
            "overlay": f"Molar mass of {formula} ≈ {mm:.6g} g/mol",
            "details": f"Computed from atomic weights (toy table) for {formula}. Result: {mm} g/mol.",
            "confidence": 0.96,
            "final": True,
            "claims": [{"id":"chem_mm","type":"math","text":"Molar mass computed","value":str(mm),"units":"","evidence_required":False}],
        }
    return None


# --- Biology expert: DNA GC content (toy) ---

def solve_biology(query: str) -> Optional[Dict[str, Any]]:
    seq = re.search(r"\b[ACGTU]{12,}\b", query.upper())
    if not seq:
        return None
    s = seq.group(0)
    s = s.replace("U", "T")
    gc = s.count("G") + s.count("C")
    pct = 100.0 * gc / max(1, len(s))
    return {
        "overlay": f"GC content ≈ {pct:.2f}% (length={len(s)})",
        "details": f"Sequence length={len(s)}; G+C={gc}; GC%={pct:.2f}.",
        "confidence": 0.95,
        "final": True,
        "claims": [{"id":"bio_gc","type":"math","text":"GC% computed","value":str(pct),"evidence_required":False}],
    }


def solve_math(query: str) -> Optional[Dict[str, Any]]:
    # Simple arithmetic pattern: "compute 12*3" or "12*3"
    q = query.strip()
    expr = None
    m = re.search(r"(?:compute|calculate|eval)\s*([\d\s\+\-\*\/\(\)\.]+)", q, re.IGNORECASE)
    if m:
        expr = m.group(1)
    elif re.fullmatch(r"[\d\s\+\-\*\/\(\)\.]+", q):
        expr = q
    if not expr:
        return None
    # Safe eval for basic arithmetic
    if re.search(r"[^\d\s\+\-\*\/\(\)\.]", expr):
        return None
    try:
        val = eval(expr, {"__builtins__": {}}, {})
        if isinstance(val, (int, float)) and (not math.isnan(float(val))) and (not math.isinf(float(val))):
            return {
                "overlay": f"Result: {val}",
                "details": f"Evaluated expression: {expr} = {val}",
                "confidence": 0.97,
                "final": True,
                "claims": [{"id":"math_eval","type":"math","text":"Expression evaluated","value":str(val),"evidence_required":False}],
            }
    except Exception:
        return None
    return None


def expert_solve(leaf_id: str, query: str) -> Optional[Dict[str, Any]]:
    if leaf_id.endswith("physics"):
        return solve_physics(query)
    if leaf_id.endswith("chemistry"):
        return solve_chemistry(query)
    if leaf_id.endswith("biology"):
        return solve_biology(query)
    if leaf_id.endswith("mathematics") or leaf_id.endswith("discrete_math") or leaf_id.endswith("statistics"):
        return solve_math(query)
    if leaf_id.endswith("ai") or leaf_id.startswith("ai."):
        # No deterministic expert; return None
        return None
    return None
