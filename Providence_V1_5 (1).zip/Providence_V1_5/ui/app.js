(() => {
  const $ = (id) => document.getElementById(id);

  const messagesEl = $("messages");
  const inputEl = $("input");
  const sendBtn = $("btn-send");
  const clearBtn = $("btn-clear");
  const exportBtn = $("btn-export");
  const statusEl = $("status");

  const dbgDecision = $("dbg-decision");
  const dbgRouter = $("dbg-router");
  const dbgTree = $("dbg-tree");
  const dbgVerification = $("dbg-verification");
  const dbgMega = $("dbg-mega");
  const dbgRaw = $("dbg-raw");

  const sessionIdKey = "providence_session_id";
  const chatKey = "providence_chat_history";

  const sessionId = (() => {
    const existing = localStorage.getItem(sessionIdKey);
    if (existing) return existing;
    const id = "sess_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
    localStorage.setItem(sessionIdKey, id);
    return id;
  })();

  let lastDebug = null;

  function setStatus(text, kind = "idle") {
    statusEl.textContent = text;
    statusEl.classList.remove("busy", "error");
    if (kind === "busy") statusEl.classList.add("busy");
    if (kind === "error") statusEl.classList.add("error");
  }

  function addMessage(role, content) {
    const wrap = document.createElement("div");
    wrap.className = "msg";

    const avatar = document.createElement("div");
    avatar.className = `avatar ${role}`;
    avatar.textContent = role === "user" ? "U" : "P";

    const bubble = document.createElement("div");
    bubble.className = `bubble ${role}`;
    bubble.textContent = content;

    wrap.appendChild(avatar);
    wrap.appendChild(bubble);
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;

    persistChat();
  }

  function persistChat() {
    const items = [];
    for (const node of messagesEl.querySelectorAll('.msg')) {
      const role = node.querySelector('.avatar').classList.contains('user') ? 'user' : 'assistant';
      const content = node.querySelector('.bubble').textContent || '';
      items.push({ role, content });
    }
    localStorage.setItem(chatKey, JSON.stringify(items.slice(-60)));
  }

  function restoreChat() {
    try {
      const raw = localStorage.getItem(chatKey);
      if (!raw) return;
      const items = JSON.parse(raw);
      for (const it of items) addMessage(it.role, it.content);
    } catch (_) {}
  }

  function pretty(obj) {
    return JSON.stringify(obj, null, 2);
  }

  function updateDebug(d) {
    lastDebug = d;

    dbgDecision.textContent = pretty(d.decision || {});
    dbgRouter.textContent = pretty(d.router || {});
    dbgTree.textContent = pretty(d.tree || {});
    dbgVerification.textContent = pretty(d.verification || {});
    dbgMega.textContent = pretty(d.mega_state || {});
    dbgRaw.textContent = pretty(d.raw || {});
  }

  async function send() {
    const msg = (inputEl.value || "").trim();
    if (!msg) return;

    addMessage("user", msg);
    inputEl.value = "";
    setStatus("Thinking…", "busy");

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: sessionId, message: msg })
      });
      if (!res.ok) {
        const t = await res.text();
        throw new Error(t || `HTTP ${res.status}`);
      }
      const data = await res.json();

      const assistant = data.assistant?.message || "(no response)";
      addMessage("assistant", assistant);

      updateDebug(data.debug || {});
      setStatus("Idle");

    } catch (err) {
      addMessage("assistant", `Error: ${err.message || err}`);
      setStatus("Error", "error");
    }
  }

  sendBtn.addEventListener('click', send);

  inputEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  });

  clearBtn.addEventListener('click', () => {
    messagesEl.innerHTML = "";
    localStorage.removeItem(chatKey);
    updateDebug({});
    setStatus("Idle");
  });

  exportBtn.addEventListener('click', () => {
    const blob = new Blob([pretty(lastDebug || {})], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'providence_debug.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  });

  restoreChat();
  if (messagesEl.children.length === 0) {
    addMessage('assistant', 'Providence UI ready. Ask a technical question (math/physics/AI/engineering).');
  }
  setStatus('Idle');
})();
